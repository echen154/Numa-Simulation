"""Compare bot parameter variants over many research seasons, in parallel.

    python sweep.py --history ../data/hurricane-season-research/history --seasons 40 --keys 3

Each variant is a dict of bot.py constants to override. Every variant runs on the same seasons, so the
differences are paired (the "vs base" column and its standard error are what to look at).
"""
import argparse, json, math, multiprocessing as mp, statistics as st
import replay_test as R
import bot as B

DEFAULTS = {k: getattr(B, k) for k in ('BAND', 'MIN_EDGE', 'CLIP', 'SWEEP', 'BETA', 'MAX_ACTIONS_PER_MIN', 'USE_GBM', 'MIN_TRADE', 'FINAL_RESERVE', 'CONF_POWER', 'PASSIVE', 'PASSIVE_FRAC')}

VARIANTS = {
    'base': {},
}


def job(a):
    history, season, name, params, kw = a
    r = R.run_season(history, season, params={**DEFAULTS, **params}, verbose=False, **kw)
    return name, season, r['pnl'], r['actions']


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--history', required=True)
    ap.add_argument('--seasons', type=int, default=40, help='use seasons 1..N spread over the 600')
    ap.add_argument('--keys', type=int, default=3)
    ap.add_argument('--half', type=float, default=0.002)
    ap.add_argument('--variants', default='', help='JSON dict of {name: {CONST: value}} to use instead of VARIANTS')
    ap.add_argument('--no-rate-limit', action='store_true')
    ap.add_argument('--out', default='', help='CSV file for per-season PnL')
    ap.add_argument('--season-list', default='', help='comma-separated seasons (instead of --seasons)')
    ap.add_argument('--simple', action='store_true', help='old fill model (unlimited size at house +/- half)')
    ap.add_argument('--impact', type=float, default=0.005, help='house price move per position limit traded')
    ap.add_argument('--spread-mult', type=float, default=1.0, help='scale the book level distances')
    a = ap.parse_args()
    variants = {'base': {}, **json.loads(a.variants)} if a.variants else VARIANTS
    seasons = [int(x) for x in a.season_list.split(',')] if a.season_list else [1 + i * 600 // a.seasons for i in range(a.seasons)]
    kw = dict(keys=a.keys, half=a.half, rate_limit=not a.no_rate_limit, book=not a.simple, impact=a.impact,
              spread_mult=a.spread_mult)
    jobs = [(a.history, s, n, p, kw) for s in seasons for n, p in variants.items()]
    with mp.Pool() as pool:
        out = pool.map(job, jobs, chunksize=1)
    res = {n: {} for n in variants}; acts = {n: [] for n in variants}
    for n, s, pnl, nact in out:
        res[n][s] = pnl; acts[n].append(nact)
    print(f"{len(seasons)} seasons, {a.keys} key(s), " + (f"half-spread {a.half:.2%}" if a.simple else
          f"book model, impact {a.impact:.2%}/limit, spread x{a.spread_mult}"))
    print(f"{'variant':<22}{'mean PnL':>11}{'median':>10}{'win%':>7}{'vs base':>10}{'±se':>8}{'act/min':>9}")
    for n in variants:
        p = [res[n][s] for s in seasons]; d = [res[n][s] - res['base'][s] for s in seasons]
        se = st.stdev(d) / math.sqrt(len(d)) if len(d) > 1 and any(d) else 0
        print(f"{n:<22}{st.mean(p):>11,.0f}{st.median(p):>10,.0f}{100 * sum(x > 0 for x in p) / len(p):>6.0f}%"
              f"{st.mean(d):>10,.0f}{se:>8,.0f}{st.mean(acts[n]) / 39:>9.0f}")
    for n in variants:
        p = sorted(res[n][s] for s in seasons); q = lambda f: p[min(len(p) - 1, int(f * len(p)))]
        print(f"{n}: worst {p[0]:,.0f}  5% {q(.05):,.0f}  25% {q(.25):,.0f}  75% {q(.75):,.0f}  95% {q(.95):,.0f}  "
              f"best {p[-1]:,.0f}  std {st.stdev(p):,.0f}  mean ±se {st.mean(p):,.0f} ±{st.stdev(p) / math.sqrt(len(p)):,.0f}")
    if a.out:
        with open(a.out, 'w') as f:
            f.write('season,' + ','.join(variants) + '\n')
            for s in seasons:
                f.write(f"{s}," + ','.join(f"{res[n][s]:.2f}" for n in variants) + '\n')
        print('per-season results saved to', a.out)


if __name__ == '__main__':
    main()
