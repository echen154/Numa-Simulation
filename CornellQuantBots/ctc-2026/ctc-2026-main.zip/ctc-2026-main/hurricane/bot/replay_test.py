"""Offline end-to-end test: replay a research season through the bot's own valuation and trading code,
against a fake exchange with a 5-level house order book shaped like the testnet's (see FakeExchange).

    python replay_test.py --history ../data/hurricane-season-research/history --season 17 [--half 0.002] [--keys 3]

The fake exchange enforces the real rate limit (60 order actions per real minute per bot key, counted in
simulated time: one market.csv row = 2 real seconds), so the PnL here is what the bot could actually trade.
`run_season()` is also used by sweep.py to test parameter changes over many seasons.
"""
import argparse, json, csv, time, types
from pathlib import Path
import bot as B

ROW_S = 2.0          # real seconds between market.csv rows


# House order book shape, measured on the testnet (results/book_snaps.json): five levels each side, at these
# distances from the house price, with sizes as a fraction of the symbol's position limit. ETFs carry 4x the
# inner fractions. Level 5 is a wall at +/-8%.
BOOK_BP = [22, 45, 170, 320, 800]
BOOK_FRAC = [0.10, 0.07, 0.30, 0.24, 3.0]
ETF_INNER = 4.0


class FakeExchange:
    """Shared positions and cash.

    book=False: the old model, every order fills in full at house price +/- half-spread.
    book=True : a 5-level house book around the market.csv price. An order walks the levels up to its limit
                price. Size we take refills over `refill_rows` rows (2 s each). Each fill also moves the house
                price against us by `impact` x (shares / position limit), decaying with a half-life of
                `impact_half_rows` rows (the house market makers skew quotes against their inventory).
    """
    def __init__(self, half, book=True, impact=0.005, refill_rows=3, impact_half_rows=15, limits=None, spread_mult=1.0):
        self.half, self.pos, self.cash, self.mid, self.n, self.etf_ops, self.now = half, {}, 0.0, {}, 0, 0, 0.0
        self.book, self.impact, self.refill_rows, self.spread_mult = book, impact, refill_rows, spread_mult
        self.decay = 0.5 ** (1 / impact_half_rows)
        self.limits = limits or {}
        self.offset, self.used = {}, {}
        self.rest = {}       # sym -> [sign, qty, price]: the unfilled part of our last order, resting on the book

    def size(self, sym, i):
        f = BOOK_FRAC[i] * (ETF_INNER if sym in B.BASKETS and i < 4 else 1)
        return max(1, int(round(f * self.limits[sym])))

    def center(self, sym):
        return self.mid[sym] * (1 + self.offset.get(sym, 0.0))

    def levels(self, sym, side):
        """[(price, available)] best first. side 'asks' or 'bids'."""
        c, sg = self.center(sym), (1 if side == 'asks' else -1)
        used = self.used.setdefault(sym, {'asks': [0] * 5, 'bids': [0] * 5})[side]
        return [(round(c * (1 + sg * self.spread_mult * BOOK_BP[i] / 1e4), 2), self.size(sym, i) - used[i]) for i in range(5)]

    def step(self):
        """Called once per row: the book refills and our price impact decays."""
        for sym in self.offset:
            self.offset[sym] *= self.decay
        for sym, u in self.used.items():
            for side in u:
                u[side] = [max(0, x - self.size(sym, i) / self.refill_rows) for i, x in enumerate(u[side])]

    def quote(self, sym):
        if not self.book:
            m = self.mid[sym]; h = m * self.half
            return {'symbol': sym, 'bid': m - h, 'ask': m + h}
        a = [(p, q) for p, q in self.levels(sym, 'asks') if q >= 1]; b = [(p, q) for p, q in self.levels(sym, 'bids') if q >= 1]
        return {'symbol': sym, 'bid': b[0][0], 'ask': a[0][0], 'bid_size': int(b[0][1]), 'ask_size': int(a[0][1])}

    def orderbook(self, sym):
        f = lambda side: [{'price': p, 'quantity': int(q)} for p, q in self.levels(sym, side) if q >= 1]
        return {'type': 'orderbook', 'symbol': sym, 'asks': f('asks'), 'bids': f('bids')}

    def fill(self, sym, side, qty, price):
        """Fill a marketable limit order; the rest is cancelled. Returns signed filled quantity."""
        sg = 1 if side == 'buy' else -1
        if not self.book:
            m = self.mid[sym]; px = m * (1 + sg * self.half)
            if (sg > 0 and price >= px - 0.006) or (sg < 0 and price <= px + 0.006):   # quotes are rounded to the cent
                self.pos[sym] = self.pos.get(sym, 0) + sg * qty; self.cash -= sg * qty * px
                return sg * qty
            return 0
        bookside = 'asks' if sg > 0 else 'bids'
        used = self.used.setdefault(sym, {'asks': [0] * 5, 'bids': [0] * 5})[bookside]
        done = 0
        for i, (px, avail) in enumerate(self.levels(sym, bookside)):
            if done >= qty or (sg > 0 and px > price + 1e-9) or (sg < 0 and px < price - 1e-9):
                break
            q = int(min(avail, qty - done))
            if q <= 0:
                continue
            used[i] += q; done += q; self.cash -= sg * q * px
        if done:
            self.pos[sym] = self.pos.get(sym, 0) + sg * done
            self.offset[sym] = self.offset.get(sym, 0.0) + sg * self.impact * done / self.limits[sym]
        if done < qty:
            self.rest[sym] = [sg, qty - done, price]
        return sg * done

    def cross_resting(self):
        """Called once per row after the house moves: a resting buy fills at its price when the house's best ask
        comes down to it (a resting sell when the best bid comes up to it), up to that level's size. No other
        traders hit our orders, so this is a conservative fill model."""
        for sym, (sg, qty, price) in list(self.rest.items()):
            px, avail = self.levels(sym, 'asks' if sg > 0 else 'bids')[0]
            if (sg > 0 and px <= price + 1e-9) or (sg < 0 and px >= price - 1e-9):
                q = int(min(qty, avail))
                if q > 0:
                    self.used[sym]['asks' if sg > 0 else 'bids'][0] += q
                    self.pos[sym] = self.pos.get(sym, 0) + sg * q; self.cash -= sg * q * price
                    self.offset[sym] = self.offset.get(sym, 0.0) + sg * self.impact * q / self.limits[sym]
                    qty -= q
            if qty > 0:
                self.rest[sym][1] = qty
            else:
                del self.rest[sym]


class FakeKey:
    """One bot key: its own rate-limit budget, trading on the shared FakeExchange."""
    def __init__(self, ex, limit):
        self.ex, self.limit, self.actions = ex, limit, []

    def budget(self):
        self.actions = [t for t in self.actions if self.ex.now - t < 60]
        return self.limit - len(self.actions)

    def get(self, path, api=True):
        if path == '/positions':
            return {'positions': [{'symbol': k, 'quantity': v} for k, v in self.ex.pos.items()]}
        if path == '/competitions/time':
            return {'state': 'running'}
        if path == '/orders/open':
            return {'orders': [{'symbol': s} for s in self.ex.rest]}
        return {}

    def action(self, method, path, body=None):
        if self.budget() <= 0:
            return None
        self.actions.append(self.ex.now)
        ex = self.ex; ex.n += 1
        if method == 'POST' and path.startswith('/etf/'):
            _, _, etf, op = path.split('/'); n = body['quantity'] * (1 if op == 'create' else -1)
            ex.pos[etf] = ex.pos.get(etf, 0) + n
            for s, q in B.BASKETS[etf].items():
                ex.pos[s] = ex.pos.get(s, 0) - n * q
            ex.etf_ops += 1
            return {'status': 'ok'}
        if method == 'POST' and path == '/orders':
            ex.fill(body['symbol'], body['side'], body['quantity'], body['price'])
        if method == 'DELETE' and path.startswith('/orders/all'):
            sym = path.partition('symbol=')[2]
            for s in ([sym] if sym else list(ex.rest)):
                ex.rest.pop(s, None)
        return {'status': 'ok'}


def run_season(history, season, half=0.002, every=1, keys=3, arb=None, rate_limit=True, nsim=1500, params=None,
               verbose=True, book=True, impact=0.005, refill_rows=3, spread_mult=1.0):
    """Replay one season. `params` overrides module constants of bot.py (e.g. {'BAND': 0.01}). Returns a dict."""
    for k, v in (params or {}).items():
        setattr(B, k, v)
    d = Path(history) / f'season-{season:03d}'
    feed = [json.loads(l) for l in open(d / 'feed.jsonl')]; rows = list(csv.DictReader(open(d / 'market.csv')))
    settle = json.load(open(d / 'settlement.json'))
    args = types.SimpleNamespace(url='http://offline', key=','.join(['x'] * keys), dry_run=False, nsim=nsim, size=1.0,
                                 offline=True)
    if not verbose:
        B.print = lambda *a, **k: None
    B.GBM_PATH = B.HERE / f'calib_gbm_fold{season * 7919 % 10}.pkl'   # a storm model that never saw this season
    bot = B.Bot(args); bot.engine.reset_season(); bot.engine.state_file = None
    bot.engine.use = bot.engine.bseason != season      # do not let the analogs see this season
    ex = FakeExchange(half, book=book, impact=impact, refill_rows=refill_rows, spread_mult=spread_mult, limits=bot.limits)
    lim = B.MAX_ACTIONS_PER_MIN if rate_limit else 10 ** 9
    fakes = [FakeKey(ex, lim) for _ in bot.apis]
    route = {id(a): f for a, f in zip(bot.apis, fakes)}
    bot.route = {s: route[id(a)] for s, a in bot.route.items()}
    bot.etf_api = route[id(bot.etf_api)]; bot.apis = fakes; bot.api = fakes[0]
    B.ARB_SETTLE_S = 0
    use_arb = (keys == 3) if arb is None else arb
    bot.control = lambda: {'etf_arb': use_arb}         # never read the live control.json in a replay
    fi = 0; t0 = time.time()
    for i, r in enumerate(rows):
        ex.now = i * ROW_S
        while fi < len(feed) and feed[fi]['time'] <= r['time']:
            bot.on_frame({'type': 'news', 'message': feed[fi]}); fi += 1
        for s in B.SYMBOLS:
            ex.mid[s] = float(r[s])
        ex.step()
        ex.cross_resting()
        bot.mkt = B.market_minutes(r['time'])
        for s in B.SYMBOLS:
            bot.quotes[s] = ex.quote(s)
            if book:
                bot.on_frame(ex.orderbook(s))
        if i % every == 0:
            bot.fair, bot.phase = bot.engine.fair(); bot.fair_t = time.time()
            bot.trade_cycle()
    pnl = ex.cash + sum(q * settle[s] for s, q in ex.pos.items())
    return {'season': season, 'pnl': pnl, 'actions': ex.n, 'etf_ops': ex.etf_ops, 'pos': ex.pos,
            'secs': time.time() - t0}


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--history', required=True); ap.add_argument('--season', type=int, default=17)
    ap.add_argument('--half', type=float, default=0.002); ap.add_argument('--every', type=int, default=1,
                                                                            help='trade every N rows (1 row = 2 real s)')
    ap.add_argument('--keys', type=int, default=3, help='number of bot keys (each has its own 60/min budget)')
    ap.add_argument('--no-arb', action='store_true', help='turn the ETF arbitrage off')
    ap.add_argument('--no-rate-limit', action='store_true', help='ignore the 60/min order-action limit (old behaviour)')
    ap.add_argument('--simple', action='store_true', help='old fill model: unlimited size at house price +/- half')
    ap.add_argument('--impact', type=float, default=0.005, help='house price move per position limit we trade')
    a = ap.parse_args()
    r = run_season(a.history, a.season, a.half, a.every, a.keys, False if a.no_arb else None, not a.no_rate_limit,
                   book=not a.simple, impact=a.impact)
    mins = 3 * 13
    print(f"season {a.season}: PnL {r['pnl']:,.0f}  ETF create/redeems {r['etf_ops']}  order actions {r['actions']} "
          f"(~{r['actions'] / mins:.0f}/min over {a.keys} key(s))  ({r['secs']:.0f}s)")
    print('final positions', r['pos'])


if __name__ == '__main__':
    main()
