"""Fast manual controls for the running bot (it re-reads control.json every cycle, about every 2 s).

    python adjust.py PORT -5          # PORT fair value $5 lower (adds to any earlier PORT adjustment)
    python adjust.py PORT x0.9        # PORT fair value 10% lower
    python adjust.py PORT reset       # remove PORT's manual adjustment
    python adjust.py flat HAVEN       # trade HAVEN back to 0 and leave it alone   (unflat HAVEN to undo)
    python adjust.py pause | resume   # stop all trading and cancel orders / start again
    python adjust.py size 0.5         # trade at half size
    python adjust.py show             # print the current controls
    python adjust.py model HAVEN_RET 600      # announcement: change a settlement-formula constant (engine.DEFAULT_PARAMS)
    python adjust.py model ISLE 60,30,0       # list-valued constants take comma-separated numbers
    python adjust.py model reset              # back to the research-data formulas
    python adjust.py preview HAVEN_RET 600    # show how fair values would move, without changing anything

Use it after an announcement: the house takes about 45 real seconds to reprice, so a quick adjustment is worth a lot.
"""
import json, os, sys
from pathlib import Path

F = Path(__file__).resolve().parent / 'control.json'


def parse(v):
    return [float(x) for x in v.split(',')] if ',' in v else float(v)


def preview(model):
    """Fair values from the saved season state (damage so far + simulated future storms), now vs with `model`.
    It does not know the live storm, so during a storm treat it as a rough guide to the direction and size."""
    try:
        import engine as E
        e = E.Engine(state_file=str(F.parent / 'season_state.json'), nsim=4000); e.state_file = None
        E.set_params({}); e.rng = __import__('numpy').random.default_rng(1); old, _ = e.fair()
        E.set_params(model); e.rng = __import__('numpy').random.default_rng(1); new, _ = e.fair()
        E.set_params({})
    except Exception as ex:
        print('preview unavailable:', ex); return
    print(f"{'symbol':<7}{'now':>8}{'new':>8}{'change':>8}")
    for s in E.SYMBOLS:
        if abs(new[s] - old[s]) > 0.005:
            print(f"{s:<7}{old[s]:>8.2f}{new[s]:>8.2f}{new[s] - old[s]:>+8.2f}")


def main(a):
    c = json.load(open(F)) if F.exists() else {}
    c.setdefault('override', {}); c.setdefault('flat', [])
    if not a or a[0] in ('-h', '--help'):
        print(__doc__); return
    cmd = a[0]
    if cmd == 'preview':
        return preview({**c.get('model', {}), a[1].upper(): parse(a[2])})
    if cmd == 'model':
        if a[1] == 'reset':
            c['model'] = {}
        else:
            c.setdefault('model', {})[a[1].upper()] = parse(a[2])
        preview(c['model'])
    elif cmd == 'pause':
        c['pause'] = True
    elif cmd == 'resume':
        c['pause'] = False
    elif cmd == 'size':
        c['size'] = float(a[1])
    elif cmd in ('flat', 'unflat'):
        for s in a[1:]:
            s = s.upper()
            if cmd == 'flat' and s not in c['flat']:
                c['flat'].append(s)
            if cmd == 'unflat' and s in c['flat']:
                c['flat'].remove(s)
    elif cmd not in ('show', 'model'):
        sym, v = cmd.upper(), a[1]
        o = c['override'].setdefault(sym, {'add': 0, 'mult': 1})
        if v == 'reset':
            del c['override'][sym]
        elif v.startswith('x'):
            o['mult'] = o.get('mult', 1) * float(v[1:])
        else:
            o['add'] = o.get('add', 0) + float(v)
    tmp = F.with_suffix('.tmp')
    json.dump(c, open(tmp, 'w'), indent=1)
    os.replace(tmp, F)                  # atomic: the bot never reads a half-written file
    print(json.dumps(c))


if __name__ == '__main__':
    main(sys.argv[1:])
