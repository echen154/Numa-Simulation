"""Fair-value engine for the CTC 2026 Hurricane Season case.

Everything here was fitted on the 600 research seasons (see STRATEGY.md for the derivations).

Settlement formulas (exact to a few cents in the research data):
    D[c]  = cumulative damage of company c as a fraction (sum of damage_pct / 100 over the season)
    C[c]  = cumulative weighted closure = sum over sites of weight * seconds_closed / 100
    L     = season insured losses ($M) = sum of 9*PORT% + 6*ISLE% + 2.5*AQUA% + 7*GRID% + 1.2*FERRY%
    Lpgf  = the part of L from PORT, GRID and FERRY

    PORT  = 100 - 55 D - 2 C          ISLE = 60 - 38 D         AQUA = 35 - 20 D
    GRID  = 50 - 24 D - 5 C           FERRY = 25 - 5 D - 6 C
    RECON = 40 + 24 (1 - exp(-Lpgf/1000))
    MAT   = 28 + 14 (1 - exp(-L/1200))
    GEN   = 32 + 18 (1 - exp(-0.83 C_GRID))
    HAVEN = 75 - 0.06 * clip(min(L,1300) - 400, 0)        (layer 400 -> 1300)
    REIN  = 90 - 0.035 * max(L - 1300, 0)                  (layer starts at 1300)
    ETFs  = basket of the above

A site is closed while wind = intensity * exp(-(dist/radius)^2) > 0.35.
Per-site damage of one storm = remaining * (1 - exp(-k * sum_t max(wind - th, 0)^p)), (th, p, k) per company.
"""
from __future__ import annotations
import json, math, os
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent
ISL = ['PORT', 'ISLE', 'AQUA', 'GRID', 'FERRY']
SYMBOLS = ['PORT', 'ISLE', 'AQUA', 'GRID', 'FERRY', 'RECON', 'MAT', 'GEN', 'HAVEN', 'REIN', 'ARCH', 'REBLD']
LP = np.array([9.0, 6.0, 2.5, 7.0, 1.2])        # $M insured loss per damage pct-point
PG = np.array([1, 0, 0, 1, 1.0])                # which companies feed RECON
BASKET = {'ARCH': {'PORT': 1, 'ISLE': 1, 'AQUA': 2, 'GRID': 1, 'FERRY': 2, 'HAVEN': 1},
          'REBLD': {'RECON': 2, 'MAT': 2, 'GEN': 1}}
CLOSE_TH = 0.35
PATS = ['direct', 'chain', 'recurve', 'stall', 'eyewall', 'erratic']
P_OFFICIAL, P_WIRE = 0.70, 0.40                 # measured outlook accuracy
NOISE_SD = 0.25                                 # log-sd of actual damage vs track model
W_MODEL, W_PRELIM = (                           # best combination of track model and preliminary report
    {'PORT': .746, 'ISLE': .75, 'AQUA': .805, 'GRID': .735, 'FERRY': .718},
    {'PORT': .245, 'ISLE': .232, 'AQUA': .186, 'GRID': .251, 'FERRY': .264})


# Settlement-formula constants. An announcement can change one of them: put the new value in control.json "model"
# (python adjust.py model HAVEN_RET 600) and every scenario is revalued with it. See ANNOUNCEMENTS.md.
DEFAULT_PARAMS = {
    'PORT': [100, 55, 2], 'ISLE': [60, 38, 0], 'AQUA': [35, 20, 0], 'GRID': [50, 24, 5], 'FERRY': [25, 5, 6],  # base, per D, per C
    'RECON': [40, 24, 1000], 'MAT': [28, 14, 1200], 'GEN': [32, 18, 0.83],      # base, max gain, scale
    'HAVEN_BASE': 75, 'HAVEN_RATE': 0.06, 'HAVEN_RET': 400, 'HAVEN_TOP': 1300,  # layer RET -> TOP, $ per $M of loss
    'REIN_BASE': 90, 'REIN_RATE': 0.035, 'REIN_ATT': 1300,
    'LOSS': [9.0, 6.0, 2.5, 7.0, 1.2],                                          # $M insured loss per damage pct-point
}
PARAMS = json.loads(json.dumps(DEFAULT_PARAMS))


def set_params(over):
    """Reset PARAMS to the defaults plus `over` (e.g. {"HAVEN_RET": 600, "ISLE": [60, 30, 0]}). Returns True if
    anything changed. Unknown keys are ignored with a message."""
    new = json.loads(json.dumps(DEFAULT_PARAMS))
    for k, v in (over or {}).items():
        if k not in new:
            print('model: unknown parameter', k); continue
        new[k] = v
    if new == PARAMS:
        return False
    PARAMS.clear(); PARAMS.update(new)
    LP[:] = PARAMS['LOSS']
    return True


def value(D, C, L, Lp):
    """Fundamental values. Inputs may be floats or numpy arrays (vectorised over scenarios)."""
    P, v = PARAMS, {}
    for c in ISL:
        a, bd, bc = P[c]
        v[c] = a - bd * D[c] - bc * C[c]
    v['RECON'] = P['RECON'][0] + P['RECON'][1] * (1 - np.exp(-Lp / P['RECON'][2]))
    v['MAT'] = P['MAT'][0] + P['MAT'][1] * (1 - np.exp(-L / P['MAT'][2]))
    v['GEN'] = P['GEN'][0] + P['GEN'][1] * (1 - np.exp(-P['GEN'][2] * C['GRID']))
    v['HAVEN'] = P['HAVEN_BASE'] - P['HAVEN_RATE'] * np.clip(np.minimum(L, P['HAVEN_TOP']) - P['HAVEN_RET'], 0, None)
    v['REIN'] = P['REIN_BASE'] - P['REIN_RATE'] * np.clip(L - P['REIN_ATT'], 0, None)
    for e, b in BASKET.items():
        v[e] = sum(q * v[s] for s, q in b.items())
    return v


class Geometry:
    def __init__(self, case):
        self.sites = {c: np.array([[s['x'], s['y'], s['weight']] for s in case['companies'][c]['sites']]) for c in ISL}
        self.dp = json.load(open(HERE / 'dmg_params.json'))
        self.slices, i = [], 0
        for c in ISL:
            n = len(self.sites[c]); self.slices.append(slice(i, i + n)); i += n
        self.nsite = i
        self.weights = np.concatenate([self.sites[c][:, 2] for c in ISL])
        self.th = np.concatenate([[self.dp[c][0]] * len(self.sites[c]) for c in ISL])
        self.pw = np.concatenate([[self.dp[c][1]] * len(self.sites[c]) for c in ISL])
        self.k = np.concatenate([[self.dp[c][2]] * len(self.sites[c]) for c in ISL])
        self.xy = np.concatenate([self.sites[c][:, :2] for c in ISL])

    def exposure(self, obs):
        """obs (n,7) [age,x,y,vx,vy,r,I] -> (site exposure e[nsite], site closure seconds/100 * weight[nsite])"""
        if len(obs) == 0:
            return np.zeros(self.nsite), np.zeros(self.nsite)
        q = np.hypot(obs[None, :, 1] - self.xy[:, 0, None], obs[None, :, 2] - self.xy[:, 1, None]) / obs[None, :, 5]
        w = obs[None, :, 6] * np.exp(-q * q)
        e = (np.clip(w - self.th[:, None], 0, None) ** self.pw[:, None]).sum(1) * self.k
        cl = 2 * (w > CLOSE_TH).sum(1) * self.weights / 100
        return e, cl

    def per_company(self, site_vals, weighted=True):
        return np.array([(site_vals[..., sl] * (self.weights[sl] if weighted else 1)).sum(-1) for sl in self.slices])


def pattern_posterior(official, wire):
    lp = np.zeros(6); P = np.array(PATS)
    for o in official:
        lp += np.log(np.where(P == o, P_OFFICIAL, (1 - P_OFFICIAL) / 5))
    for w in wire:
        lp += np.log(np.where(P == w, P_WIRE, (1 - P_WIRE) / 5))
    p = np.exp(lp - lp.max()); return p / p.sum()


class Engine:
    """Feed it every news message (in seq order); ask it for fair values at any time."""

    def __init__(self, case=None, state_file=None, k_analogs=40, nsim=3000, exclude_season=None):
        case = case or json.load(open(HERE / 'case.json'))
        self.g = Geometry(case)
        B = np.load(HERE / 'storm_bank.npz')
        self.bobs, self.SF, self.CL = B['obs'].astype(float), B['SF'], B['CL']
        self.bpat, self.bflip, self.bseason = B['pattern'], B['flip'], B['season']
        self.use = np.ones(len(self.SF), bool) if exclude_season is None else (self.bseason != exclude_season)
        self.k_analogs, self.nsim = k_analogs, nsim
        self.rng = np.random.default_rng(7)
        self.state_file = state_file
        self.reset_season()
        if state_file and os.path.exists(state_file):
            self.load()

    # ----- season state -------------------------------------------------------------------
    def reset_season(self):
        self.rem = np.ones(self.g.nsite); self.D = np.zeros(5); self.C = np.zeros(5); self.L = 0.0; self.Lp = 0.0
        self.done_rounds = set(); self.round = 1; self.date = None
        self.comp_id = getattr(self, 'comp_id', None)   # the exchange's competition id of this season
        self.new_storm()
        self.seen = set(); self.offsets = {}

    def new_storm(self):
        self.obs = {}; self.official = []; self.wire = []; self.prelim = None; self.final = None
        self.formed = False; self.dissipated = False; self.storm = None

    def save(self):
        if not self.state_file:
            return
        json.dump({'rem': self.rem.tolist(), 'D': self.D.tolist(), 'C': self.C.tolist(), 'L': self.L, 'Lp': self.Lp,
                   'done_rounds': sorted(self.done_rounds), 'date': self.date, 'comp_id': self.comp_id},
                  open(self.state_file, 'w'))

    def load(self):
        s = json.load(open(self.state_file))
        self.rem = np.array(s['rem']); self.D = np.array(s['D']); self.C = np.array(s['C'])
        self.L, self.Lp = s['L'], s['Lp']; self.done_rounds = set(s['done_rounds']); self.date = s.get('date')
        self.comp_id = s.get('comp_id')

    def set_competition(self, cid):
        """Each season has its own competition id (the testnet makes a new one per season). If it differs from
        the id our saved state belongs to, the state is from another season: start clean. Returns True on reset."""
        if not cid or cid == self.comp_id:
            return False
        if self.comp_id is None:             # state saved before ids were recorded (or no state): adopt, don't wipe
            self.comp_id = cid; self.save(); return False
        old = self.comp_id
        self.reset_season(); self.comp_id = cid; self.save()
        if old:
            print(f'new competition id {cid[:8]}: season state reset')
        return True

    # ----- feed ---------------------------------------------------------------------------
    def on_message(self, m):
        t = m.get('type')
        if t == 'snapshot':
            return self.on_snapshot(m)
        seq = m.get('seq')
        if seq is not None:
            if seq in self.seen:
                return
            self.seen.add(seq)
        r = m.get('round')
        if isinstance(r, int) and r != self.round:
            if r < self.round or (r == 1 and self.round > 1):
                self.reset_season()          # a new season started (testnet)
            self.round = r; self.new_storm()
        if m.get('storm') and m.get('storm') != self.storm:
            if self.storm is not None and self.final is None and r == self.round:
                pass
            if self.storm is not None:
                self.new_storm()
            self.storm = m['storm']
        if t == 'storm':
            self.obs[int(m['age'])] = (m['age'], m['x'], m['y'], m['vx'], m['vy'], m['radius'], m['intensity'])
        elif t == 'track':
            for a, x, y, rad in m['points']:      # fill gaps (no velocity/intensity in track points)
                a = int(a)
                if a not in self.obs:
                    prev = [v for k, v in self.obs.items() if k < a]
                    inten = prev[-1][6] if prev else 1.0
                    self.obs[a] = (a, x, y, 0.0, 0.0, rad, inten)
        elif t == 'storm_formed':
            self.formed = True
        elif t == 'storm_dissipated':
            self.dissipated = True
        elif t == 'advisory':
            (self.official if m.get('source') == 'official' else self.wire).append(m['outlook'])
        elif t == 'damage_report':
            if m['stage'] == 'preliminary':
                self.prelim = m
            else:
                self.final = m
                if self.round not in self.done_rounds:
                    self.apply_final(m)
        elif t == 'announcement':
            print('ANNOUNCEMENT (not modelled, check by hand):', m.get('headline'), m.get('symbols'))

    def on_snapshot(self, s):
        """A snapshot summarises the current round (or the round that closed last), with every damage report of
        the season. Used when the bot starts or reconnects mid-season."""
        r = s.get('round')
        if isinstance(r, int) and r != self.round:          # take the round from the snapshot, not our default
            if r < self.round:
                self.reset_season()
            self.round = r; self.new_storm()
        if s.get('storm') and self.storm is None:
            self.storm = s['storm']
        for a, x, y, rad in (s.get('track') or []):
            if int(a) not in self.obs:
                self.obs[int(a)] = (a, x, y, 0, 0, rad, (s.get('obs') or {}).get('intensity', 1.0))
        if s.get('obs'):
            o = s['obs']; self.obs[int(o['age'])] = (o['age'], o['x'], o['y'], o['vx'], o['vy'], o['radius'], o['intensity'])
        adv = s.get('advisory')
        if isinstance(adv, dict) and adv.get('outlook') and not self.official:
            self.official.append(adv['outlook'])
        if s.get('phase') in ('aftermath', 'closed') or self.obs and max(self.obs) >= 480:
            self.dissipated = True
        # rebuild any final damage reports we missed, oldest first
        for m in sorted((m for m in s.get('damage') or [] if m.get('stage') == 'final'), key=lambda m: m.get('round', 0)):
            rr = m.get('round')
            if rr in self.done_rounds:
                continue
            if rr == self.round:
                self.final = m; self.apply_final(m, rnd=rr)      # this round: split by the snapshot's track
            else:
                print(f'note: round {rr} damage recovered from snapshot (exact totals; site split approximate)')
                self.apply_final(m, obs=np.zeros((0, 7)), rnd=rr)

    def obs_array(self):
        if not self.obs:
            return np.zeros((0, 7))
        return np.array([self.obs[k] for k in sorted(self.obs)], float)

    def apply_final(self, m, obs=None, rnd=None):
        obs = self.obs_array() if obs is None else obs
        e, cl = self.g.exposure(obs)
        ds = self.rem * (1 - np.exp(-e))
        rep = np.array([m['damage_pct'][c] for c in ISL])
        for i, sl in enumerate(self.g.slices):
            pred = 100 * (ds[sl] * self.g.weights[sl]).sum()
            if pred > 1e-9:
                ds[sl] *= rep[i] / pred
            elif rep[i] > 0:
                ds[sl] = self.rem[sl] * rep[i] / 100 / max((self.rem[sl] * self.g.weights[sl]).sum(), 1e-9)
        self.rem = np.clip(self.rem - ds, 0, 1)
        self.D += rep / 100; self.C += self.g.per_company(cl, weighted=False)
        self.L += (LP * rep).sum(); self.Lp += (LP * PG * rep).sum()
        self.done_rounds.add(rnd or self.round); self.save()

    # ----- forecasting --------------------------------------------------------------------
    def analogs(self, obs, post):
        a = int(obs[-1, 0]) // 2
        hist = list(range(max(0, a - 60), a + 1, 5))
        idx = {int(o[0]) // 2: o for o in obs}
        live = np.array([idx[i][1:3] if i in idx else [np.nan, np.nan] for i in hist]); ok = ~np.isnan(live[:, 0])
        P = self.bobs[:, hist, 1:3][:, ok]
        d = np.nansum(((P - live[ok]) ** 2).sum(2), 1) / max(ok.sum(), 1)
        d += 200 * ((self.bobs[:, a, 3:5] - obs[-1, 3:5]) ** 2).sum(1)
        d[~self.use] = np.inf; d[np.isnan(d)] = np.inf
        pa = np.where(2 * a >= self.bflip, PATS.index('erratic'), self.bpat)
        nn_all, w_all = [], []
        for pi, pp in enumerate(post):
            if pp < 0.01:
                continue
            cand = np.where((pa == pi) & np.isfinite(d))[0]
            if len(cand) == 0:
                continue
            kk = max(3, int(round(self.k_analogs * pp))); nn = cand[np.argsort(d[cand])[:kk]]
            w = np.exp(-d[nn] / max(np.median(d[nn]), 1e-6)); w = w / w.sum() * pp
            nn_all += list(nn); w_all += list(w)
        w = np.array(w_all); return np.array(nn_all, int), w / w.sum(), a

    def storm_completions(self):
        """Site damage fractions (of remaining) and closure for the current storm: list of (w, sf[nsite], cl[nsite])."""
        obs = self.obs_array()
        e0, c0 = self.g.exposure(obs)
        if self.dissipated or (len(obs) and obs[-1, 0] >= 480):
            return [(1.0, 1 - np.exp(-e0), c0)]
        if len(obs) == 0:
            return None
        post = pattern_posterior(self.official, self.wire)
        nn, w, a = self.analogs(obs, post)
        out = []; cur = obs[-1, 1:3]
        for j, wt in zip(nn, w):
            fut = self.bobs[j, a + 1:]; fut = fut[~np.isnan(fut[:, 0])].copy()
            if len(fut):
                off = cur - self.bobs[j, a, 1:3]
                fut[:, 1:3] += off * np.exp(-(fut[:, 0] - 2 * a) / 120.0)[:, None]
            e1, c1 = self.g.exposure(fut)
            out.append((wt, 1 - np.exp(-(e0 + e1)), c0 + c1))
        return out

    def simulate(self, rem0, D0, C0, L0, Lp0, n_future):
        """rem0 (n,nsite) etc. Applies n_future random research storms. Returns value dict of arrays."""
        rem = rem0.copy(); D = D0.copy(); C = C0.copy(); L = L0.copy(); Lp = Lp0.copy(); n = len(rem)
        for _ in range(n_future):
            idx = self.rng.choice(np.where(self.use)[0], n)
            noise = np.exp(self.rng.normal(-NOISE_SD ** 2 / 2, NOISE_SD, (n, 5)))
            nz = np.concatenate([np.repeat(noise[:, i:i + 1], sl.stop - sl.start, 1) for i, sl in enumerate(self.g.slices)], 1)
            ds = np.minimum(rem * self.SF[idx] * nz, rem); rem -= ds
            add = self.g.per_company(ds).T                     # (n,5) fraction of original value
            D += add; C += self.CL[idx]; L += (add * 100) @ LP; Lp += (add * 100 * PG) @ LP
        return value({c: D[:, i] for i, c in enumerate(ISL)}, {c: C[:, i] for i, c in enumerate(ISL)}, L, Lp)

    def phase(self):
        if self.round in self.done_rounds:
            return 'final'
        if self.prelim is not None:
            return 'prelim'
        if self.dissipated:
            return 'aftermath'
        if self.obs:
            return 'storm'
        return 'pre_storm'

    def fair(self):
        """Expected settlement value of every symbol given everything seen so far."""
        n_after = 3 - self.round                       # storms in later rounds
        ph = self.phase()
        N = self.nsim
        base = lambda n: (np.tile(self.rem, (n, 1)), np.tile(self.D, (n, 1)), np.tile(self.C, (n, 1)),
                          np.full(n, self.L), np.full(n, self.Lp))
        if ph == 'final':
            if n_after == 0:
                v = value(dict(zip(ISL, self.D)), dict(zip(ISL, self.C)), self.L, self.Lp)
                return {k: float(x) for k, x in v.items()}, ph
            v = self.simulate(*base(N), n_after)
        elif ph == 'pre_storm':
            v = self.simulate(*base(N), n_after + 1)
        else:
            comps = self.storm_completions()
            if comps is None:
                v = self.simulate(*base(N), n_after + 1)
            else:
                if ph == 'prelim':          # replace the damage level with the model/prelim blend
                    w0, sf, cl = comps[0]
                    model_pct = 100 * self.g.per_company(self.rem * sf)
                    pre = np.array([self.prelim['damage_pct'][c] for c in ISL])
                    target = np.array([W_MODEL[c] * model_pct[i] + W_PRELIM[c] * pre[i] for i, c in enumerate(ISL)])
                    scale = np.where(model_pct > 1e-6, target / np.maximum(model_pct, 1e-6), 1.0)
                    sf = sf.copy()
                    for i, sl in enumerate(self.g.slices):
                        if model_pct[i] > 1e-6:
                            sf[sl] = np.minimum(sf[sl] * scale[i], 1)
                        elif pre[i] > 0:
                            sf[sl] = np.minimum(pre[i] / 100 / max((self.rem[sl] * self.g.weights[sl]).sum(), 1e-9), 1)
                    comps = [(1.0, sf, cl)]; sd = 0.16      # residual error after blending
                else:
                    sd = NOISE_SD
                per = max(50, N // len(comps))
                vals = {k: 0.0 for k in SYMBOLS}
                for wt, sf, cl in comps:
                    rem, D, C, L, Lp = base(per)
                    noise = np.exp(self.rng.normal(-sd ** 2 / 2, sd, (per, 5)))
                    nz = np.concatenate([np.repeat(noise[:, i:i + 1], sl.stop - sl.start, 1) for i, sl in enumerate(self.g.slices)], 1)
                    ds = np.minimum(rem * sf * nz, rem); rem = rem - ds
                    add = self.g.per_company(ds).T
                    D = D + add; C = C + self.g.per_company(cl, weighted=False)[None, :]
                    L = L + (add * 100) @ LP; Lp = Lp + (add * 100 * PG) @ LP
                    vv = self.simulate(rem, D, C, L, Lp, n_after)
                    for k in SYMBOLS:
                        vals[k] += wt * float(np.mean(vv[k]))
                return vals, ph
        return {k: float(np.mean(x)) for k, x in v.items()}, ph
