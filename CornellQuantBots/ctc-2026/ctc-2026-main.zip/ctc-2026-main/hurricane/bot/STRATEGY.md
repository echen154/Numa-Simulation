# Hurricane Season: model, findings and bot

Everything below was measured on the 600 research seasons (1,800 storms).

## 1. Settlement values are exact formulas

Notation, for the whole season so far:

* `D[c]` – cumulative damage of island company `c`, as a fraction: the sum of the `damage_pct` values in the final damage reports, divided by 100.
* `C[c]` – cumulative weighted closure: the sum over the company's sites of `site weight × seconds closed / 100` (storm-age seconds).
* `L` – season insured losses in $M. It is exactly `9·PORT% + 6·ISLE% + 2.5·AQUA% + 7·GRID% + 1.2·FERRY%` (damage pct-points).
* `Lpgf` – the part of `L` from PORT, GRID and FERRY.

| Symbol | Settlement value | Fit error |
|---|---|---|
| PORT | 100 − 55·D − 2·C | ±0.02 |
| ISLE | 60 − 38·D | exact |
| AQUA | 35 − 20·D | exact |
| GRID | 50 − 24·D − 5·C | ±0.02 |
| FERRY | 25 − 5·D − 6·C | ±0.02 |
| RECON | 40 + 24·(1 − e^(−Lpgf/1000)) | exact |
| MAT | 28 + 14·(1 − e^(−L/1200)) | exact |
| GEN | 32 + 18·(1 − e^(−0.83·C_GRID)) | ±0.03 |
| HAVEN | 75 − 0.06·clip(min(L,1300) − 400, 0) | exact |
| REIN | 90 − 0.035·max(L − 1300, 0) | exact |
| ARCH, REBLD | basket of the above | exact |

So the insurance layers are: **retention $400M, HavenBridge layer $400M–$1,300M, Meridian Re from $1,300M** (the top of the REIN layer was never reached; highest research season was $1,766M). HAVEN goes from 75 to its floor of 21 across its layer, which is why it drops so hard; REIN does not move at all until the season passes $1.3B.

Closures matter: FERRY loses 6 per 100 weighted closure-seconds but only 5 per 100% damage, so FERRY is mostly a closure (time under hurricane wind) play, while ISLE and AQUA are pure damage plays.

## 2. The storm physics

* **Wind at a site** = `intensity × exp(−(distance/radius)²)`. A site is **closed while wind > 0.35**. This reproduces the impact messages to within one observation (2 s).
* **Damage of one storm at a site** = `remaining × (1 − exp(−k·Σ max(wind − th, 0)^p))`, summed every 2 s over the track. Damage compounds on what is left. Fitted (th, p, k) per company are in `dmg_params.json`. The track model is unbiased with about 25% (log) error per storm.
* Storms are independent across rounds. Later rounds look milder only because damage compounds.

## 3. The information sources

* **Official outlook**: right 70% of the time; when wrong, each other outlook is equally likely. Consecutive advisories are close to independent, so combine them: the Bayesian posterior names the true pattern 72% after 1 advisory, 87% after 3, 93% after 4.
* **Wire chatter**: right 40% of the time (vs 17% for a guess), wrong uniformly otherwise. Worth a small weight, not zero.
* **Preliminary damage report**: biased +5% and about ±33% noisy. **The track model is about twice as accurate.** Best estimate ≈ 0.75 × track model + 0.25 × preliminary.
* **Final damage report**: exact.

## 4. The house

* **It is pessimistic.** At the season open it underprices the island companies and HAVEN and overprices the rebuilders and REIN. Average (settlement − house open) over 600 seasons: HAVEN +1.8, ARCH +3.2, PORT +0.6, GRID +0.3, ISLE +0.2, AQUA +0.1; REBLD −1.8, RECON −0.6, MAT −0.2, GEN −0.2, REIN −0.4. Our model's fair values agree in direction at every round open.
* It catches up with the final damage report within about 4 real seconds for stocks, and about 10 real seconds for the ETFs. ARCH is off by about 3 for those 10 seconds.
* After the preliminary report it is about as accurate as our model; the edge after the storm is small except GEN and the ETFs.
* During the storm our pattern-aware forecast and the house are similarly accurate on average, and their disagreement predicts the settlement (regression slope 0.3–0.5), so the bot shrinks its edge toward the house mid during the storm.

## 5. Backtest

The bot's engine was replayed over all 600 research seasons (each season's own storms excluded from the analogs), trading toward fair value every 10 real seconds at the house price plus a half-spread.

| Variant | Half-spread 0.1% | Half-spread 0.3% | Seasons won |
|---|---|---|---|
| Trust the model fully in every phase (bot default) | $23.7k / season | $19.5k | 94–96% |
| Shrink edge 50% toward the house | $20.3k | $16.2k | 91–94% |
| Trade only during the storm | $16.1k | $13.0k | 86–89% |
| Never trade during the storm | $3.5k | $2.9k | 55% |
| Trade only before storms / after final reports | $2.9k | – | 56% |

Standard error is about $550 per row. Two lessons: **most of the edge is during the storm** (Bayesian outlook combination plus track-based damage), and the structural house bias adds a few thousand per season but is noisy. These numbers assume you can always trade at the house consensus; real spreads, depth and other teams will cut them, so check spreads on the testnet and raise `MIN_EDGE` if fills are poor.

## 6. Files

| File | Use |
|---|---|
| `engine.py` | Season state, storm forecaster, fair values. Feed it news messages, call `fair()`. |
| `bot.py` | The live bot: WebSocket feed, valuation thread, trading thread, rate limits, live controls. Takes up to 3 comma-separated bot keys; ETF arbitrage runs when it has all 3. |
| `replay_test.py` | Replays a research season through the bot's own code against a fake exchange. Run this first. |
| `storm_bank.npz` | The 1,800 research storm tracks and their per-site damage/closure, used as analogs and future storms. |
| `case.json`, `dmg_params.json` | Map, sites and fitted damage parameters. |
| `control.json` | Live controls (pause, size, manual overrides, flatten). |

## 7. Competition-day checklist

1. `pip install "websockets>=14" numpy` on the laptop that runs the bot.
2. Run `python replay_test.py --history <path>/history --season 17` to confirm everything loads.
3. On the testnet: run `bot.py --dry-run` for a round, check the quote frames parse (the bot expects `{"type":"quote","symbol":…,"bid":…,"ask":…}`), and that `/positions` parses. Adjust `positions()` and `on_frame()` if the field names differ.
4. Before the live season: `python bot.py --url … --key … --new-season`. The season state is saved in `season_state.json` after each final report, so a restart mid-season keeps it (do **not** pass `--new-season` on a restart).
5. **Announcements are not in the research data and are not modelled.** When one arrives the bot prints it. Decide by hand what it changes (for example a new site weight, a reinsurance change, a capacity change) and put the effect in `control.json → override` for that symbol, or put the symbol in `flat`. The house takes about 45 real seconds to adjust, so a fast manual override is worth a lot.
6. Keep one person watching the log and `control.json`; set `"pause": true` if anything looks wrong.

## 8. Realistic-book backtest (added Oct 22)

The testnet house book has 5 levels a side at about ±0.22%, ±0.45%, ±1.7%, ±3.2% and a wall at ±8%, with sizes of 10%, 7%,
30%, 24% and 300% of the position limit (ETFs: 4× the inner sizes). `replay_test.py` now simulates that book, with
refill over 3 rows and a house price impact of 0.5% per position limit traded. Under it (40 seasons, 3 keys, rate limit on):

| Change | PnL / season vs previous |
|---|---|
| Walk the book (SWEEP) instead of best price only | −$5.5k ± 1.1k → SWEEP off |
| Bigger clips (CLIP 0.5 / 1.0) | −$1.7k / −$2.1k → keep 0.25 |
| BETA 0.7 before and during the storm | +$0.45k ± 0.13k → adopted |
| BAND, MIN_EDGE changes | not significant |

Final settings: about $16k / season mean, 90% of seasons profitable, 5% worst ≈ −$2.5k (vs $24.6k with unlimited fills).

## 9. Machine-learning edge model (tested Oct 22, switched off)

`analysis/calib_build.py` → `calib_fit.py` → `calib_train.py` build 4.2M samples (engine fair, house mid, context, settlement)
from all 600 seasons and train a gradient-boosting model of (settlement − mid). Out of sample it predicted slightly better
than the engine (MSE 94.7 vs 95.2) and about 10% better per trade during the storm. But in the realistic 80-season
backtest, using it during the storm made **$768 ± 757 less** per season than BETA. The engine's fair value is already close
to the best available signal. `USE_GBM` in bot.py turns it back on for experiments.
