"""Read-only testnet check. Places NO orders. Run this once with your bot key before running bot.py.

    python check_connection.py --url https://cornelltradingcompetition.org 

It prints the raw shape of every response the bot depends on, then checks that bot.py's parsers
(Bot.positions, Bot.resting_symbols, Bot.on_frame quote handling) read them correctly.
"""
import argparse, asyncio, json, types
import bot as B


def show(name, x):
    s = json.dumps(x, default=str)
    print(f'--- {name}: {s[:600]}{" ..." if len(s) > 600 else ""}')


async def feed(url, key, secs):
    import websockets
    ws_url = url.replace('https://', 'wss://', 1).replace('http://', 'ws://', 1).rstrip('/') + '/ws/v1/market-data'
    sub = {"action": "subscribe", "symbols": B.SYMBOLS, "channels": ["news", "quotes"]}
    seen = {}
    async with websockets.connect(ws_url, additional_headers={'X-API-Key': key}, max_size=2 ** 23) as ws:
        await ws.send(json.dumps(sub))
        try:
            async with asyncio.timeout(secs):
                async for frame in ws:
                    d = json.loads(frame)
                    k = d.get('type'), (d.get('message') or {}).get('type') if isinstance(d.get('message'), dict) else None
                    if k not in seen:
                        seen[k] = d; show(f'frame {k}', d)
        except TimeoutError:
            pass
    return seen


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--url', required=True); ap.add_argument('--key', default=None, help='default: first key in bot/keys.txt')
    ap.add_argument('--secs', type=int, default=20, help='how long to listen to the WebSocket')
    a = ap.parse_args()
    a.key = a.key or B.read_keys()
    api = B.Api(a.url, a.key.split(',')[0], dry=True)
    for path, raw in [('/competitions/time', True), ('/positions', True), ('/orders/open', True),
                      ('/orderbook/PORT', True), ('/cases/hurricane.json', False)]:
        try:
            show(path, api.get(path, api=raw))
        except Exception as e:
            print(f'--- {path}: FAILED {e}')
    try:
        seen = asyncio.run(feed(a.url, api.key, a.secs))
    except Exception as e:
        print(f'--- WebSocket FAILED: {e}  (403 = wrong bot key)'); seen = {}

    print('\n=== does bot.py parse these? ===')
    bot = types.SimpleNamespace(api=api, apis=[api], working=set(), quotes={})
    print('positions ->', B.Bot.positions(bot), '  (should be {symbol: signed quantity}, {} if flat)')
    print('resting   ->', B.Bot.resting_symbols(bot), '  (symbols with open orders)')
    q = seen.get(('quote', None))
    if q is None:
        print('quote     -> NO quote frame seen. Is the market open? If it is, bot.on_frame expects type "quote".')
    else:
        B.Bot.on_frame(bot, q); sym = q.get('symbol')
        ok = sym in bot.quotes and all(isinstance(bot.quotes[sym].get(f), (int, float)) for f in ('bid', 'ask'))
        print('quote     ->', 'OK' if ok else 'PROBLEM: bot expects top-level "symbol", "bid", "ask"', q)
        print('sizes     ->', 'present' if 'bid_size' in q else 'no bid_size/ask_size (ETF arb will not cap size by depth)')
    print('news      ->', 'OK' if any(k[0] == 'news' for k in seen) else 'no news frame in this window (normal between events)')


if __name__ == '__main__':
    main()
