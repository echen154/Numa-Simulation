# Announcement playbook

The live season can have company or government announcements (data README: "an announcement changes the economics
of a company from that time"). The research data has none, so the engine cannot learn them. A human has to act, and
the house takes about **45 real seconds** to reprice, so be fast:

1. The bot prints `ANNOUNCEMENT (not modelled, check by hand): <headline> <symbols>`.
2. **First 5 s (whoever watches the log):** if the row below is obvious, run it. Otherwise `python adjust.py flat SYM`
   for the named symbols (plus ARCH or REBLD if they hold them). Until then the bot trades *against* the news: the
   house reprices, the bot thinks the move is mispricing, and leans the wrong way.
3. **Next 30-60 s:** paste the full announcement text into the Claude session. Claude finds the row, runs `preview`,
   then `model` (or a `$` override), unflats, and reports new fair vs house mid.
4. Check the bot log shows `model parameters now: ...`. The bot reprices within about 2 s.

A `model` change is better than a flat `$` override (`adjust.py SYM -5`), because the engine recomputes every
scenario with the new formula. That matters for the layered names: a retention change moves HAVEN by a different
amount depending on how big this season's losses will be. Use a `$` override only when no constant fits.

## Settlement constants you can change (`engine.DEFAULT_PARAMS`)

| Constant | Default | Meaning |
|---|---|---|
| `PORT` `ISLE` `AQUA` `GRID` `FERRY` | e.g. PORT `100,55,2` | base value, $ lost per 100% damage (D), $ lost per 100 weighted closure-seconds (C) |
| `RECON` / `MAT` | `40,24,1000` / `28,14,1200` | base, max gain, loss scale $M (gain = max·(1−e^(−L/scale))) |
| `GEN` | `32,18,0.83` | base, max gain, rate per GRID closure |
| `HAVEN_RET`, `HAVEN_TOP`, `HAVEN_RATE`, `HAVEN_BASE` | 400, 1300, 0.06, 75 | HavenBridge layer from RET to TOP $M, $ per $M of loss in the layer |
| `REIN_ATT`, `REIN_RATE`, `REIN_BASE` | 1300, 0.035, 90 | Meridian Re attaches at ATT $M |
| `LOSS` | `9,6,2.5,7,1.2` | insured $M per damage pct-point of PORT, ISLE, AQUA, GRID, FERRY (feeds L: HAVEN, REIN, MAT, RECON) |

## Likely announcements → command

| Announcement | Command (example numbers: read them off the headline) | Effect |
|---|---|---|
| HavenBridge raises its retention to $600M | `model HAVEN_RET 600` | HAVEN, ARCH up |
| HavenBridge limit cut / layer now ends at $1,000M | `model HAVEN_TOP 1000` | HAVEN up; and if Meridian now starts there, also `model REIN_ATT 1000` (REIN down) |
| Meridian Re attaches lower, at $1,100M | `model REIN_ATT 1100` | REIN down |
| A company buys more insurance / insured value up 50% (ISLE) | `model LOSS 9,9,2.5,7,1.2` | L rises: HAVEN, REIN down; MAT, RECON up |
| A company drops its insurance | set its `LOSS` entry to 0 | HAVEN up, MAT/RECON down |
| ISLE gets a government guarantee: only 30 lost per 100% damage | `model ISLE 60,30,0` | ISLE, ARCH up (damage already taken is revalued too) |
| GRID gets backup generators: outages cost 2 not 5 | `model GRID 50,24,2` | GRID up; GEN unchanged (GEN uses GRID closure, not GRID price) |
| Special dividend / one-off cash of $X per share | `adjust.py SYM +X` | plain $ shift |
| Merger / buyout at $P | `adjust.py SYM reset`, `adjust.py SYM x0`, `adjust.py SYM +P` (fair = P exactly) | ETF: shift by weight × (P − old fair) |
| Site hardened / sea wall (future damage at one site lower) | `$` override = value of the expected future damage avoided at that site (ask Claude to compute) | SYM, ARCH up |
| Site destroyed, closed for good, new site, site weight changed | `$` override (ask Claude) | |
| RECON capacity / rebuilding contract | `model RECON 40,X,1000` | RECON, REBLD |
| Materials price controls / shortage | `model MAT 28,X,1200` | MAT, REBLD |
| Grid backup program / generator contract | `model GEN 32,X,0.83` | GEN, REBLD |
| Insurer downgrade / default risk | `$` override on HAVEN or REIN | HAVEN also moves ARCH |
| ETF basket change | `flat ARCH REBLD` (and turn off arb: `"etf_arb": false` in control.json) | |
| Trading halt / delisting | `flat SYM` | |
| Storm or forecast news | nothing: the feed and model already have it | |
| Unclear, or 4+ symbols affected | `pause`, then ask Claude | |

**`$` overrides do not reach the ETFs.** The engine computes ETF fair values from its own stock values, so after
`adjust.py AQUA -3` also run `adjust.py ARCH -6` (weight × $). ARCH = PORT 1, ISLE 1, AQUA 2, GRID 1, FERRY 2, HAVEN 1;
REBLD = RECON 2, MAT 2, GEN 1. `model` changes flow to the ETFs automatically.

**"From that time" caveat:** a coefficient change also revalues damage that already happened this season. If the
announcement only applies to *future* storms, the preview overstates the move: scale it by the share of expected
damage still to come (about 2/3 before round 2's storm, 1/3 before round 3's), using `adjust.py SYM +X` instead.

Undo everything: `python adjust.py model reset` and `python adjust.py SYM reset`.

**Prepare before the round.** Each person should run two or three previews, so on the day it's muscle memory:
```
python adjust.py preview HAVEN_RET 600
python adjust.py preview LOSS 9,9,2.5,7,1.2
python adjust.py preview GRID 50,24,2
```
