"""Hurricane Season trading bot (CTC 2026).

    pip install "websockets>=14" numpy
    python bot.py --url https://cornelltradingcompetition.org --key BOT_KEY --dry-run
    python bot.py --url ... --key ...                      # live
    python bot.py --url ... --key KEY1,KEY2,KEY3           # live, three bot keys (3x the order rate)

What it does
  * Feeds every news message to engine.Engine, which keeps the season state (damage, closures,
    insured losses) and computes the expected settlement value of all 12 symbols.
  * Every cycle it compares fair value with the house mid, shrinks the gap by a phase-dependent
    trust factor (BETA), and moves each position toward a target proportional to the edge,
    within position limits and the order-action rate limit.

Live controls (edit while the bot runs; re-read every cycle)
  control.json  {"pause": false, "size": 1.0, "override": {"PORT": {"add": 0, "mult": 1}}, "flat": []}
     pause    : true -> cancel all orders and stop trading
     size     : scales every target position (0..1)
     override : adjust a fair value by hand, e.g. after an announcement the engine cannot model
     flat     : symbols to trade back to zero and then leave alone
     etf_arb  : true/false -> ETF create/redeem arbitrage (default: on only with three keys)

Several bot keys
  The exchange allows 60 order actions a minute per bot key and 180 per team. With up to three
  comma-separated keys the bot gives each key its own group of symbols (KEY_GROUPS), so it can
  send three times as many orders. Make the extra keys on the Team page.

ETF arbitrage
  Creating or redeeming an ETF is free and instant. When ARCH or REBLD trades away from the cost of
  its basket by more than the spreads plus ARB_MARGIN, the bot sells the dear side, buys the cheap
  side, and then creates or redeems to cancel the legs out. In the research data ARCH was more than
  $2 away from its basket 10% of the time, and REBLD 2% of the time.
"""
from __future__ import annotations
import os
os.environ.setdefault('OMP_NUM_THREADS', '1')   # the storm model predicts 12 rows at a time: one thread is fastest
import argparse, asyncio, collections, json, math, os, threading, time, urllib.error, urllib.request
from pathlib import Path

from engine import Engine, SYMBOLS, pattern_posterior, set_params

HERE = Path(__file__).resolve().parent
HEADERS = {"User-Agent": "ctc-hurricane-bot/1.0", "Content-Type": "application/json"}

# How much of (fair - house) to believe, by engine phase. Realistic-book sweep (40 seasons): trusting the model 70%
# before/during the storm beat full trust by +$446 +/- 133 per season; after the storm full trust is best.
BETA = {'pre_storm': 0.7, 'storm': 0.7, 'aftermath': 1.0, 'prelim': 1.0, 'final': 1.0}
BAND = 0.015          # an adjusted edge of BAND * price gives a full-size target position
MIN_EDGE = 0.003      # do not trade unless the adjusted edge beats this fraction of price (plus half-spread)
MAX_ACTIONS_PER_MIN = 54   # per key; the exchange allows 60
MIN_TRADE = 0.0       # skip a trade smaller than this fraction of the limit (less churn); flattening always trades
CLIP = 0.25           # largest single order, as a fraction of the position limit
# Storm-phase edge model (analysis/calib_train.py): gradient boosting that predicts (settlement - mid)/mid from the
# engine's edge and context. Used instead of BETA while the storm is active, where it beat BETA out of sample.
USE_GBM = False       # off: in the 80-season realistic backtest it did not beat BETA ($768 +/- 757 worse)
GBM_PATH = HERE / 'calib_gbm.pkl'
PHASES = ['pre_storm', 'storm', 'aftermath', 'prelim', 'final']
LAG_MIN = 15          # market minutes (30 real s) for the recent-price-move feature
SWEEP = False         # True = walk the order book level by level. Off: in the realistic backtest it lost ~$5.5k/season (deeper levels cost 1-3%)
CYCLE_S = 2.0
# Final-report race: the house reprices stocks ~4 s and ETFs ~10 s after the final damage report. While waiting for it
# (aftermath / preliminary report) keep this many order actions per key unspent, so the bot can trade the moment it lands.
FINAL_RESERVE = 0
# Confidence sizing: during the storm, scale target positions by (posterior probability of the likeliest pattern) ** CONF_POWER.
# 0 = off. One official advisory gives ~0.72, three give ~0.87.
CONF_POWER = 0.0
# Passive orders: when the edge beats MIN_EDGE but not half-spread + MIN_EDGE, rest a limit order one tick inside the
# spread for PASSIVE_FRAC of the limit instead of doing nothing. Stale passive orders are cancelled when the edge goes.
PASSIVE = False
PASSIVE_FRAC = 0.25
TICK = 0.01
FILL_REPORT_S = 60    # print the fill rate (shares filled / shares sent) this often; low = other teams take the edge first
# With several keys, each key trades one group. The ETF group also runs the ETF arbitrage.
KEY_GROUPS = [['PORT', 'ISLE', 'AQUA', 'GRID', 'FERRY'], ['RECON', 'MAT', 'GEN', 'HAVEN', 'REIN'], ['ARCH', 'REBLD']]
BASKETS = {'ARCH': {'PORT': 1, 'ISLE': 1, 'AQUA': 2, 'GRID': 1, 'FERRY': 2, 'HAVEN': 1},
           'REBLD': {'RECON': 2, 'MAT': 2, 'GEN': 1}}
ARB_MARGIN = 0.40     # dollars per ETF share of profit required on top of all spreads
ARB_MAX = 10          # ETF shares per arbitrage trade
ARB_COOLDOWN_S = 4.0
ARB_SETTLE_S = 0.3   # wait for the legs to fill before creating or redeeming


def read_keys():
    """Bot keys from bot/keys.txt (one per line, gitignored) so they never go on the command line."""
    try:
        keys = [l.strip() for l in open(HERE / 'keys.txt') if l.strip() and not l.startswith('#')]
    except FileNotFoundError:
        keys = []
    if not keys:
        raise SystemExit('no bot keys: put them in bot/keys.txt, one per line, or pass --key')
    return ','.join(keys[:3])


def market_minutes(ts):
    """'1825-04-11T10:15:30' -> ('1825-04-11', minutes since the 09:30 open)."""
    day, hms = ts[:10], ts[11:19]
    h, m, sec = (int(x) for x in hms.split(':'))
    return day, h * 60 + m + sec / 60 - 570


class Api:
    def __init__(self, url, key, dry):
        self.url, self.key, self.dry = url.rstrip('/'), key, dry
        self.actions = collections.deque()

    def _req(self, method, path, body=None, api=True):
        req = urllib.request.Request(self.url + ('/api/v1' if api else '') + path, method=method,
                                     data=None if body is None else json.dumps(body).encode(),
                                     headers={**HEADERS, 'X-API-Key': self.key})
        with urllib.request.urlopen(req, timeout=5) as r:
            txt = r.read().decode()
            return json.loads(txt) if txt else {}

    def get(self, path, api=True):
        return self._req('GET', path, api=api)

    def budget(self):
        now = time.time()
        while self.actions and now - self.actions[0] > 60:
            self.actions.popleft()
        return MAX_ACTIONS_PER_MIN - len(self.actions)

    def action(self, method, path, body=None):
        if self.budget() <= 0:
            return None
        self.actions.append(time.time())
        if self.dry:
            print('DRY', method, path, body or '')
            return {'status': 'dry'}
        try:
            return self._req(method, path, body)
        except urllib.error.HTTPError as e:
            print('REJECT', method, path, body, e.code, e.read().decode()[:200])
        except Exception as e:  # network hiccup
            print('ERROR', method, path, e)
        return None


class Bot:
    def __init__(self, args):
        self.args = args
        keys = [k.strip() for k in args.key.split(',') if k.strip()][:3]
        self.apis = [Api(args.url, k, args.dry_run) for k in keys]
        self.api = self.apis[0]                      # reads (positions, clock) use the first key
        if len(self.apis) == 1:
            self.route = {s: self.apis[0] for s in SYMBOLS}
        else:
            groups = KEY_GROUPS if len(self.apis) == 3 else [KEY_GROUPS[0] + KEY_GROUPS[2], KEY_GROUPS[1]]
            self.route = {s: self.apis[i] for i, g in enumerate(groups) for s in g}
        self.etf_api = self.route['ARCH']
        self.working = set()                         # symbols where we may have a resting order
        self.last_arb = 0.0
        print(f'using {len(self.apis)} bot key(s)')
        self.case = None
        if not getattr(args, 'offline', False):
            try:
                self.case = self.api.get('/cases/hurricane.json', api=False)
            except Exception as e:
                print('could not fetch case data, using local case.json:', e)
        self.engine = Engine(case=self.case, state_file=str(HERE / 'season_state.json'), nsim=args.nsim)
        if not getattr(args, 'offline', False):
            try:      # saved state from another season (another competition id) is thrown away
                self.engine.set_competition(self.api.get('/competitions/time').get('competition_id'))
            except Exception as e:
                print('could not read the competition clock:', e)
        self.limits = (self.case or json.load(open(HERE / 'case.json')))['limits']
        self.quotes = {}
        self.books = {}                              # latest 'orderbook' frame per symbol (5 levels a side)
        self.gbm = None
        if USE_GBM:
            try:
                import pickle
                self.gbm = pickle.load(open(GBM_PATH, 'rb'))
            except Exception as e:
                print('storm model not loaded, using BETA:', e)
        self.mkt = None                              # (day, market minutes since 09:30) of the latest clock reading
        self.news_at = None                          # (day, minutes) of the latest important news
        self.mid_hist = {s: collections.deque() for s in SYMBOLS}
        self.lock = threading.Lock()
        self.news_evt = threading.Event()            # set by important news: revalue now instead of waiting
        self.fair_evt = threading.Event()            # set after each valuation: trade on it now
        self.fair, self.phase, self.fair_t = {}, 'pre_storm', 0
        self.passive = {}                            # sym -> (side, price) of our resting passive order
        self.fills = {'sent': 0, 'filled': 0, 'last_pos': None, 't': time.time()}
        offline = getattr(args, 'offline', False)        # replays/sweeps: no log file
        self.log = open(os.devnull if offline else HERE / f'bot_log_{int(time.time())}.csv', 'a')
        self.log.write('t,phase,symbol,fair,adj,mid,pos,target\n')

    # ---------------- feed ----------------
    def on_frame(self, d):
        t = d.get('type')
        if t == 'quote':
            self.quotes[d['symbol']] = d
        elif t == 'orderbook':
            self.books[d['symbol']] = d
        elif t == 'news' and isinstance(d.get('message'), dict):
            with self.lock:
                self.engine.on_message(d['message'])
            m = d['message']
            if m.get('type') in ('advisory', 'damage_report', 'impact', 'announcement', 'storm_formed', 'storm_dissipated'):
                print(f"[{m.get('time')}] {m.get('headline', m.get('type'))}")
                self.news_evt.set()
            if m.get('type') in ('advisory', 'damage_report', 'impact', 'storm_formed', 'storm_dissipated') and m.get('time'):
                self.news_at = market_minutes(m['time'])

    async def ws_loop(self):
        import websockets
        sub = {"action": "subscribe", "symbols": SYMBOLS, "channels": ["news", "quotes", "orderbook"]}
        ws_url = self.args.url.replace('https://', 'wss://', 1).replace('http://', 'ws://', 1).rstrip('/') + '/ws/v1/market-data'
        while True:
            try:
                async with websockets.connect(ws_url, additional_headers={'X-API-Key': self.apis[0].key}, max_size=2 ** 23) as ws:
                    await ws.send(json.dumps(sub)); print('connected to market data')
                    async for frame in ws:
                        self.on_frame(json.loads(frame))
            except (OSError, websockets.exceptions.WebSocketException) as e:
                print('market data disconnected:', e); await asyncio.sleep(1)

    # ---------------- valuation ----------------
    def valuation_loop(self):
        while True:
            t0 = time.time()
            try:
                with self.lock:
                    if set_params(self.control().get('model')):     # announcement: settlement formula changed
                        print('model parameters now:', self.control().get('model'))
                    fv, ph = self.engine.fair()
                self.fair, self.phase, self.fair_t = fv, ph, time.time()
                self.fair_evt.set()
            except Exception as e:
                print('valuation error', repr(e))
            # sleep until the next 2 s tick, or wake early on important news
            if self.news_evt.wait(max(0.1, 2.0 - (time.time() - t0))):
                self.news_evt.clear()

    # ---------------- trading ----------------
    def control(self):
        try:
            return json.load(open(HERE / 'control.json'))
        except Exception:
            return {}

    def mid(self, sym):
        q = self.quotes.get(sym) or {}
        b, a = q.get('bid'), q.get('ask')
        if b is None or a is None:
            return None, None, None
        return (b + a) / 2, b, a

    def positions(self):
        try:
            p = self.api.get('/positions')
            rows = p.get('positions', p) if isinstance(p, dict) else p
            out = {}
            for r in rows if isinstance(rows, list) else []:
                out[r.get('symbol')] = r.get('quantity', r.get('position', 0)) or 0
            return out
        except Exception as e:
            print('positions error', e); return None

    def resting_symbols(self):
        """Symbols where we have a resting order. GET /orders/open is a read, not an order action, so checking is
        cheaper than a blind cancel. Falls back to the symbols we traded (self.working) if the read fails."""
        out = set()
        try:
            for api in self.apis:
                o = api.get('/orders/open')
                rows = o.get('orders', o) if isinstance(o, dict) else o
                out |= {r.get('symbol') for r in rows if isinstance(r, dict)} if isinstance(rows, list) else set()
            return out
        except Exception as e:
            print('open orders error', e); return set(self.working)

    def take(self, sym, side, need, adj, mid):
        """How many shares to take now and at what limit price. With SWEEP, walk the book level by level while
        each level's price still leaves MIN_EDGE * mid of edge against our fair value `adj`. Without a book
        (or SWEEP off), take only the best price, capped by its displayed size when the quote has one."""
        stop = adj - MIN_EDGE * mid if side == 'buy' else adj + MIN_EDGE * mid
        ok = (lambda p: p <= stop) if side == 'buy' else (lambda p: p >= stop)
        book = self.books.get(sym)
        if SWEEP and book:
            levels = sorted(book.get('asks' if side == 'buy' else 'bids') or [], key=lambda l: l['price'],
                            reverse=side == 'sell')
            qty, px = 0, None
            for l in levels:
                if qty >= need or not ok(l['price']):
                    break
                qty += min(int(l['quantity']), need - qty); px = l['price']
            return (qty, px) if qty else (0, None)
        q = self.quotes.get(sym) or {}
        px = q.get('ask' if side == 'buy' else 'bid')
        if px is None or not ok(px):
            return 0, None
        sz = q.get('ask_size' if side == 'buy' else 'bid_size')
        return (min(need, int(sz)) if isinstance(sz, (int, float)) and sz > 0 else need), px

    def storm_model(self, ctl):
        """Predicted edge ($/share) of each symbol from the storm-phase model, or {} if unavailable. Symbols with a
        manual override keep the BETA rule, so the override acts exactly as typed."""
        if self.gbm is None or self.mkt is None:
            return {}
        import numpy as np
        day, now = self.mkt
        with self.lock:
            post = pattern_posterior(self.engine.official, self.engine.wire)
            nadv, rnd = len(self.engine.official), self.engine.round
        since = 60.0 if self.news_at is None or self.news_at[0] != day else min(60.0, now - self.news_at[1])
        rows, syms = [], []
        for j, sym in enumerate(SYMBOLS):
            mid = self.mid(sym)[0]
            if mid is None or sym not in self.fair or sym in (ctl.get('override') or {}):
                continue
            h = self.mid_hist[sym]
            past = next((m for t, m in reversed(h) if t <= now - LAG_MIN), h[0][1] if h else mid)
            rows.append([(self.fair[sym] - mid) / mid, j, PHASES.index('storm'), rnd, now, post.max(), nadv, since,
                         (mid - past) / mid])
            syms.append((sym, mid))
        if not rows:
            return {}
        pred = self.gbm.predict(np.array(rows))
        return {sym: float(p) * mid for (sym, mid), p in zip(syms, pred)}

    def record_mids(self):
        """Keep the last 30 market minutes of mid prices (for the recent-price-move feature)."""
        if self.mkt is None:
            return
        now = self.mkt[1]
        for sym in SYMBOLS:
            mid = self.mid(sym)[0]
            if mid is None:
                continue
            h = self.mid_hist[sym]
            if h and h[-1][0] > now:          # a new market day: minutes restart at 0
                h.clear()
            h.append((now, mid))
            while h and h[0][0] < now - 2 * LAG_MIN:
                h.popleft()

    def track_fills(self, pos):
        """Fill rate = |position change| / shares we sent. Run once per cycle, before new orders. Cycles with an ETF
        create/redeem are skipped by the caller (those move positions without a trade)."""
        f = self.fills
        if getattr(self.args, 'dry_run', False):
            return                     # nothing fills in a dry run
        if f['last_pos'] is not None:
            f['filled'] += sum(abs(pos.get(s, 0) - f['last_pos'].get(s, 0)) for s in SYMBOLS)
        f['last_pos'] = dict(pos)
        if time.time() - f['t'] >= FILL_REPORT_S and f['sent']:
            print(f"fill rate {f['filled']}/{f['sent']} shares = {100 * min(1, f['filled'] / f['sent']):.0f}% "
                  f"(low means other traders take the edge first: consider raising MIN_EDGE)")
            f['sent'] = f['filled'] = 0; f['t'] = time.time()

    def conf_scale(self):
        if not CONF_POWER or self.phase != 'storm':
            return 1.0
        with self.lock:
            p = pattern_posterior(self.engine.official, self.engine.wire).max()
        return float(p) ** CONF_POWER

    def trade_cycle(self):
        ctl = self.control()
        try:
            clock = self.api.get('/competitions/time')
        except Exception:
            clock = {}
        if clock.get('competition_id'):
            with self.lock:
                if self.engine.set_competition(clock['competition_id']):
                    self.fair = {}                   # do not trade on the old season's values
        if clock.get('fictional_time'):
            self.mkt = market_minutes(clock['fictional_time'])
        if clock.get('state') not in (None, 'running', 'open'):
            return
        if ctl.get('pause'):
            for api in self.apis:
                api.action('DELETE', '/orders/all')
            self.working.clear(); self.passive.clear(); return
        self.record_mids()
        if not self.fair or time.time() - self.fair_t > 10:
            return
        pos = self.positions()
        if pos is None:
            return
        self.track_fills(pos)
        if ctl.get('etf_arb', len(self.apis) == 3) and self.etf_arb(pos):
            self.fills['last_pos'] = None   # create/redeem moves positions without a trade: restart the count
            return                     # positions changed; plan the directional trades next cycle
        size = float(ctl.get('size', self.args.size)) * self.conf_scale()
        reserve = FINAL_RESERVE if self.phase in ('aftermath', 'prelim') else 0
        beta = BETA.get(self.phase, 0.5)
        storm_edge = self.storm_model(ctl) if self.phase == 'storm' else {}
        plan = []
        for sym in SYMBOLS:
            mid, bid, ask = self.mid(sym)
            if mid is None or sym not in self.fair:
                continue
            ov = (ctl.get('override') or {}).get(sym, {})
            fair = self.fair[sym] * ov.get('mult', 1) + ov.get('add', 0)
            adj = mid + storm_edge[sym] if sym in storm_edge else mid + beta * (fair - mid)
            edge = adj - mid
            half = (ask - bid) / 2
            lim = self.limits[sym]
            cur = pos.get(sym, 0)
            passive = False
            if sym in (ctl.get('flat') or []):
                target = 0
            elif PASSIVE and MIN_EDGE * mid + TICK <= abs(edge) < half + MIN_EDGE * mid:
                # too small to cross the spread, big enough to rest inside it: hold at least PASSIVE_FRAC of the limit
                want = int(math.copysign(PASSIVE_FRAC * lim * size, edge))
                target = cur if cur * want > 0 and abs(cur) >= abs(want) else want
                passive = True
            elif abs(edge) < half + MIN_EDGE * mid:
                target = cur                        # no edge: hold
            else:
                net = edge - math.copysign(half, edge)
                target = int(max(-1, min(1, net / (BAND * mid))) * lim * size)
            self.log.write(f'{time.time():.1f},{self.phase},{sym},{fair:.4f},{adj:.4f},{mid:.4f},{cur},{target}\n')
            if target != cur and (abs(target - cur) >= MIN_TRADE * lim or target == 0):
                plan.append((abs(edge) / mid * abs(target - cur) / lim, sym, cur, target, bid, ask, adj, passive))
        self.log.flush()
        plan.sort(reverse=True)
        planned = {p[1] for p in plan}
        for sym in [s for s in self.passive if s not in planned]:     # edge gone: pull the stale passive order
            if self.route[sym].action('DELETE', f'/orders/all?symbol={sym}') is not None:
                del self.passive[sym]
        resting = self.resting_symbols() if plan else set()
        for _, sym, cur, target, bid, ask, adj, passive in plan:
            api = self.route[sym]
            if api.budget() < 2 + reserve:
                continue
            diff = target - cur
            lim = self.limits[sym]
            side = 'buy' if diff > 0 else 'sell'
            need = min(abs(diff), max(1, int(lim * CLIP)))     # at most CLIP of the limit per order
            if passive:
                px = round(bid + TICK if side == 'buy' else ask - TICK, 2)
                if not (bid < px < ask) or abs(adj - px) < MIN_EDGE * (bid + ask) / 2 or (adj > px) != (side == 'buy'):
                    continue
                if self.passive.get(sym) == (side, px) and sym in resting:
                    continue           # already resting there: do not spend actions replacing it
                qty = need
            else:
                qty, px = self.take(sym, side, need, adj, (bid + ask) / 2)
                if qty <= 0:           # no price left that beats our fair value by MIN_EDGE
                    continue
            order = {"symbol": sym, "side": side, "order_type": "limit", "quantity": qty, "price": round(px, 2)}
            if sym in resting:             # cancel our old order first, so there is at most one per symbol
                api.action('DELETE', f'/orders/all?symbol={sym}')
            if api.action('POST', '/orders', order) is not None:
                self.working.add(sym); self.fills['sent'] += qty
                if passive:
                    self.passive[sym] = (side, px)
                else:
                    self.passive.pop(sym, None)

    # ---------------- ETF arbitrage ----------------
    def etf_arb(self, pos):
        """Sell the dear side, buy the cheap side, then create or redeem so the legs cancel."""
        if time.time() - self.last_arb < ARB_COOLDOWN_S:
            return
        for etf, basket in BASKETS.items():
            q_etf = self.quotes.get(etf) or {}
            qs = {s: self.quotes.get(s) or {} for s in basket}
            if q_etf.get('bid') is None or q_etf.get('ask') is None or any(q.get('bid') is None or q.get('ask') is None for q in qs.values()):
                continue
            buy_basket = sum(n * qs[s]['ask'] for s, n in basket.items())
            sell_basket = sum(n * qs[s]['bid'] for s, n in basket.items())
            if q_etf['bid'] - buy_basket > ARB_MARGIN:      # ETF dear: sell ETF, buy basket, create
                side, gap = 'create', q_etf['bid'] - buy_basket
            elif sell_basket - q_etf['ask'] > ARB_MARGIN:   # ETF cheap: buy ETF, sell basket, redeem
                side, gap = 'redeem', sell_basket - q_etf['ask']
            else:
                continue
            sign = 1 if side == 'redeem' else -1             # +1 = we buy the ETF
            k = ARB_MAX
            k = min(k, self.limits[etf] - sign * pos.get(etf, 0))          # room on the ETF leg
            for s, n in basket.items():
                k = min(k, (self.limits[s] + sign * pos.get(s, 0)) // n)  # room on each stock leg
            for q in [q_etf] + list(qs.values()):           # do not take more than the top of the book shows
                sz = q.get('ask_size' if (q is q_etf) == (sign > 0) else 'bid_size')
                if isinstance(sz, (int, float)) and sz > 0:
                    k = min(k, int(sz) // (1 if q is q_etf else max(basket.values())))
            if k <= 0:
                continue
            api = self.etf_api
            if api.budget() < len(basket) + 2:
                continue
            print(f'ETF ARB {side} {k} {etf}: gap ${gap:.2f}/share')
            etf_side = 'buy' if sign > 0 else 'sell'
            api.action('POST', '/orders', {"symbol": etf, "side": etf_side, "order_type": "limit", "quantity": k,
                                           "price": round(q_etf['ask'] if sign > 0 else q_etf['bid'], 2)})
            for s, n in basket.items():
                stock_side = 'sell' if sign > 0 else 'buy'
                api.action('POST', '/orders', {"symbol": s, "side": stock_side, "order_type": "limit", "quantity": k * n,
                                               "price": round(qs[s]['bid'] if sign > 0 else qs[s]['ask'], 2)})
                self.working.add(s)
            self.working.add(etf)
            time.sleep(ARB_SETTLE_S)
            after = self.positions() or {}
            # create/redeem only as many shares as both legs actually filled
            d_etf = sign * (after.get(etf, 0) - pos.get(etf, 0))
            d_bsk = min(-sign * (after.get(s, 0) - pos.get(s, 0)) // n for s, n in basket.items())
            done = max(0, min(k, d_etf, d_bsk))
            if done:
                api.action('POST', f'/etf/{etf}/{side}', {"quantity": done})
            self.last_arb = time.time()
            return True
        return False

    def trade_loop(self):
        while True:
            self.fair_evt.wait(CYCLE_S)          # trade right after each new valuation (or every CYCLE_S anyway)
            self.fair_evt.clear()
            try:
                self.trade_cycle()
            except Exception as e:
                print('trade error', repr(e))
            time.sleep(0.2)

    async def run(self):
        threading.Thread(target=self.valuation_loop, daemon=True).start()
        threading.Thread(target=self.trade_loop, daemon=True).start()
        await self.ws_loop()


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--url', required=True)
    ap.add_argument('--key', default=None, help='bot keys, comma-separated (default: read bot/keys.txt)')
    ap.add_argument('--size', type=float, default=1.0, help='fraction of position limits to use')
    ap.add_argument('--nsim', type=int, default=3000)
    ap.add_argument('--dry-run', action='store_true')
    ap.add_argument('--new-season', action='store_true', help='forget saved season state (use at the start of the live season)')
    args = ap.parse_args()
    args.key = args.key or read_keys()
    if args.new_season and (HERE / 'season_state.json').exists():
        os.remove(HERE / 'season_state.json')
    try:
        asyncio.run(Bot(args).run())
    except KeyboardInterrupt:
        print('stopped (resting orders stay on the exchange: run "python adjust.py pause" first to cancel them)')


if __name__ == '__main__':
    main()
