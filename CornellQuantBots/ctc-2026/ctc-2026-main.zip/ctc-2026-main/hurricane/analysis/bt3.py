import pickle,json,numpy as np,pandas as pd,sys
from pathlib import Path
from forecast import *
from model import value
R=Path('../data/hurricane-season-research/history')
T=pickle.load(open('tracks.pkl','rb')); df=pd.read_pickle('seasons.pkl').sort_index()
keys=sorted(T); F=Forecaster([np.array(T[k]['obs']) for k in keys]); kidx={k:i for i,k in enumerate(keys)}
SYM=['PORT','ISLE','AQUA','GRID','FERRY','RECON','MAT','GEN','HAVEN','REIN','ARCH','REBLD']
def site_state(s,upto):
    """per-site remaining fraction and cumulative state after rounds < upto, using final reports"""
    rem={co:np.ones(len(SITES[co])) for co in ISL}; D={co:0.0 for co in ISL}; Cc={co:0.0 for co in ISL}; L=0;Lp=0
    for r in range(1,upto):
        o=np.array(T[(s,r)]['obs'])
        for i,co in enumerate(ISL):
            e,cl=exposure(o,co); ds=rem[co]*(1-np.exp(-e)); pred=(SITES[co][:,2]*ds).sum()*100
            rep=df.loc[s,f'd{r}_{co}']
            if pred>1e-9: ds=ds*rep/pred
            rem[co]=np.clip(rem[co]-ds,0,1); D[co]+=rep/100; Cc[co]+=cl.sum()
        L+=sum(LP[i]*df.loc[s,f'd{r}_{co}'] for i,co in enumerate(ISL)); Lp+=sum(LP[i]*PG[i]*df.loc[s,f'd{r}_{co}'] for i,co in enumerate(ISL))
    return rem,D,Cc,L,Lp
ages=[20,60,120,180,240,300,360,420,480]
rows=[]
for s in list(df.index)[::int(sys.argv[1]) if len(sys.argv)>1 else 2]:
    rem,D,Cc,L,Lp=site_state(s,3)
    o=np.array(T[(s,3)]['obs']); mk=pd.read_csv(R/f'season-{s:03d}'/'market.csv'); g=mk[mk['round']==3].reset_index(drop=True)
    excl=[kidx[(s,r)] for r in (1,2,3)]
    for a in ages:
        part=o[o[:,0]<=a]
        dist=F.complete(part,rem,exclude=excl)
        fv={k:0.0 for k in SYM}
        for wt,dp,cl in dist:
            D2={co:D[co]+dp[i]/100 for i,co in enumerate(ISL)}; C2={co:Cc[co]+cl[i] for i,co in enumerate(ISL)}
            v=value(D2,C2,L+(LP*dp).sum(),Lp+(LP*PG*dp).sum())
            for k in SYM: fv[k]+=wt*v[k]
        row_i=30+a//2+2   # market row: 60 pre-storm s =30 rows; +a/2 ; +2 rows ~ house lag allowance
        hp=g.iloc[min(row_i,len(g)-1)]
        for k in SYM: rows.append(dict(s=s,age=a,sym=k,fair=fv[k],house=hp[k],settle=df.loc[s,'set_'+k]))
X=pd.DataFrame(rows); X.to_pickle('bt3.pkl')
X['ef']=(X.fair-X.settle).abs(); X['eh']=(X.house-X.settle).abs()
print(X.pivot_table(index='sym',columns='age',values='ef').round(2)); print(X.pivot_table(index='sym',columns='age',values='eh').round(2))
