import pickle,numpy as np,pandas as pd
from scipy.optimize import least_squares
T=pickle.load(open('tracks.pkl','rb')); df=pd.read_pickle('seasons.pkl').set_index('season')
keys=sorted(T)
O={k:np.array(T[k]['obs']) for k in keys}
site=(470,80)
Q=[];I=[];dmg=[];prev=[]
for k in keys:
    s,r=k;o=O[k]; Q.append(np.hypot(o[:,1]-site[0],o[:,2]-site[1])/o[:,5]); I.append(o[:,6])
    dmg.append(df.loc[s,f'd{r}_PORT']/100); prev.append(sum(df.loc[s,f'd{j}_PORT'] for j in range(1,r))/100)
dmg=np.array(dmg);prev=np.array(prev)
def pred(p,form):
    out=[]
    for q,i in zip(Q,I):
        if form=='exp': w=i*np.exp(-(q/p[0])**p[1])
        else: w=i*np.clip(1-q/p[0],0,None)**p[1]
        e=(np.clip(w-p[2],0,None)**p[3]).sum()*p[4]
        out.append(e)
    e=np.array(out)
    return (1-prev)*(1-np.exp(-e))
for form,p0 in [('exp',[1.2,2,0.3,1.5,0.05]),('lin',[2.0,1.5,0.2,1.5,0.05])]:
    f=least_squares(lambda p:pred(p,form)-dmg,p0,bounds=([0.2,0.3,0,0.3,1e-5],[5,8,0.95,6,10]))
    r=pred(f.x,form)-dmg
    print(form,f.x.round(4),'rmse %.4f'%np.sqrt((r**2).mean()),'maxabs %.3f'%abs(r).max())
