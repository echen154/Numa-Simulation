import sys,json,time,numpy as np,pandas as pd
sys.path.insert(0,'../bot')
from engine import Engine,SYMBOLS
from pathlib import Path
R=Path('../data/hurricane-season-research/history')
def run_season(s,every=5,nsim=1500,k=40):
    E=Engine(nsim=nsim,k_analogs=k,exclude_season=s)
    feed=[json.loads(l) for l in open(R/f'season-{s:03d}'/'feed.jsonl')]
    mk=pd.read_csv(R/f'season-{s:03d}'/'market.csv'); st=json.load(open(R/f'season-{s:03d}'/'settlement.json'))
    fi=0; out=[]
    for i,row in mk.iterrows():
        while fi<len(feed) and feed[fi]['time']<=row['time']:
            E.on_message(feed[fi]); fi+=1
        if i%every==0:
            fv,ph=E.fair()
            out.append(dict(i=i,time=row['time'],round=row['round'],phase=ph,**{'f_'+k:fv[k] for k in SYMBOLS},**{'h_'+k:row[k] for k in SYMBOLS}))
    X=pd.DataFrame(out)
    for k in SYMBOLS: X['s_'+k]=st[k]
    X['season']=s
    return X
if __name__=='__main__':
    t=time.time(); seasons=[int(x) for x in sys.argv[1].split(',')] if ',' in sys.argv[1] else list(range(int(sys.argv[1]),int(sys.argv[2])+1,int(sys.argv[3])))
    res=[]
    for s in seasons:
        res.append(run_season(s)); print(s,round(time.time()-t,1),flush=True)
    pd.concat(res).to_pickle(f'bteng_{seasons[0]}_{seasons[-1]}.pkl')
