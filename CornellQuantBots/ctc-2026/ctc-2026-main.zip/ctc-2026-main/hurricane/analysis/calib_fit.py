"""Fit the edge-calibration model on calib_data/ and evaluate it out of sample (10 folds, split by season).

Target  y = settlement - house mid (the real edge of buying at mid), per symbol, at each sampled time.
Inputs  x = engine fair - house mid (the model's edge) and context: phase, round, time in round, forecast confidence,
        rows since the last news, recent house price change.

Models compared (all predict y):
  zero     : no edge (the house is right)
  beta     : current bot, BETA[phase] * x
  lin      : per symbol and phase, least squares y = a + b x            (shrunk toward b=1, a=0)
  gbm      : gradient boosting on x and all context features, one model for all symbols

Score = the mean "trading return" of acting on the prediction: sign(pred) * y where |pred| > half-spread + MIN_EDGE,
in $ per share and in % of price. Also MSE. Writes calib_model.json (lin coefficients from all data).

    cd analysis && ../.venv/bin/python calib_fit.py
"""
import json, sys
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'bot'))
from engine import SYMBOLS   # noqa: E402

PHASES = ['pre_storm', 'storm', 'aftermath', 'prelim', 'final']
BETA = {'pre_storm': 0.7, 'storm': 0.7, 'aftermath': 1.0, 'prelim': 1.0, 'final': 1.0}
COST = 0.0022 + 0.003            # half-spread + MIN_EDGE, as a fraction of price
LAG = 15                          # rows (30 s) for the recent house move feature


def load():
    X = []
    for f in sorted((HERE / 'calib_data').glob('season-*.npz')):
        d = np.load(f); s = int(f.stem[-3:]); n = len(d['row'])
        rows = d['row'].astype(int)
        mid = d['mids'][rows]; past = d['mids'][np.maximum(rows - LAG, 0)]
        for j in range(12):
            X.append(np.column_stack([np.full(n, s), np.full(n, j), d['phase'], d['round'], d['rrow'], d['conf'],
                                      d['nadv'], d['since_news'], mid[:, j], d['fair'][:, j], past[:, j],
                                      np.full(n, d['settle'][j])]))
    A = np.concatenate(X)
    cols = ['season', 'sym', 'phase', 'round', 'rrow', 'conf', 'nadv', 'since', 'mid', 'fair', 'past', 'settle']
    return {c: A[:, i] for i, c in enumerate(cols)}


def features(D):
    mid = D['mid']
    return np.column_stack([(D['fair'] - mid) / mid, D['sym'], D['phase'], D['round'], D['rrow'], D['conf'],
                            D['nadv'], np.minimum(D['since'], 60), (mid - D['past']) / mid])


def score(pred, y, mid):
    act = np.abs(pred) > COST * mid
    ret = np.sign(pred[act]) * y[act]
    return {'trades%': 100 * act.mean(), '$/share': ret.mean() if act.any() else 0,
            'ret%': 100 * (ret / mid[act]).mean() if act.any() else 0, 'mse': np.mean((pred - y) ** 2)}


def fit_lin(D, idx, lam=50.0):
    """Per (symbol, phase): y = a + b x, ridge-shrunk toward a=0, b=1 (lam = pseudo-observations)."""
    coef = {}
    x = D['fair'] - D['mid']; y = D['settle'] - D['mid']
    for j in range(12):
        for p in range(5):
            m = idx & (D['sym'] == j) & (D['phase'] == p)
            xs, ys = x[m], y[m]
            sc = max(np.std(xs), 1e-6)
            # solve [a,b] minimising sum (y - a - b x)^2 + lam*sc^2*(b-1)^2 + lam*sc^2*a^2/sc^2
            A = np.array([[len(xs) + lam, xs.sum()], [xs.sum(), (xs * xs).sum() + lam * sc * sc]])
            r = np.array([ys.sum(), (xs * ys).sum() + lam * sc * sc])
            a, b = np.linalg.solve(A, r) if len(xs) else (0.0, 1.0)
            coef[(j, p)] = (float(a), float(b))
    return coef


def pred_lin(coef, D, idx):
    x = (D['fair'] - D['mid'])[idx]; out = np.empty(idx.sum())
    s, p = D['sym'][idx].astype(int), D['phase'][idx].astype(int)
    for (j, ph), (a, b) in coef.items():
        m = (s == j) & (p == ph); out[m] = a + b * x[m]
    return out


def main():
    from sklearn.ensemble import HistGradientBoostingRegressor
    D = load()
    n = len(D['mid']); print(f'{n:,} samples, {len(np.unique(D["season"]))} seasons')
    y = D['settle'] - D['mid']; mid = D['mid']; F = features(D)
    fold = (D['season'].astype(int) * 7919) % 10
    preds = {k: np.zeros(n) for k in ('zero', 'beta', 'lin', 'gbm')}
    preds['beta'] = np.array([BETA[PHASES[int(p)]] for p in D['phase']]) * (D['fair'] - mid)
    for k in range(10):
        tr, te = fold != k, fold == k
        coef = fit_lin(D, tr); preds['lin'][te] = pred_lin(coef, D, te)
        g = HistGradientBoostingRegressor(max_iter=300, learning_rate=0.05, max_leaf_nodes=31, min_samples_leaf=200,
                                          l2_regularization=1.0, categorical_features=[1, 2], random_state=0)
        g.fit(F[tr], (y / mid)[tr]); preds['gbm'][te] = g.predict(F[te]) * mid[te]
        print(f'fold {k} done', flush=True)
    print(f"\n{'model':<6}{'trades%':>9}{'$/share':>9}{'ret%':>8}{'mse':>9}")
    for k, p in preds.items():
        s = score(p, y, mid); print(f"{k:<6}{s['trades%']:>9.1f}{s['$/share']:>9.3f}{s['ret%']:>8.3f}{s['mse']:>9.2f}")
    print('\nby phase, ret% (beta / lin / gbm):')
    for ph in range(5):
        m = D['phase'] == ph
        print(f"  {PHASES[ph]:<10}" + ''.join(f"{score(preds[k][m], y[m], mid[m])['ret%']:>8.3f}" for k in ('beta', 'lin', 'gbm')))
    coef = fit_lin(D, np.ones(n, bool))
    json.dump({SYMBOLS[j]: {PHASES[p]: coef[(j, p)] for p in range(5)} for j in range(12)},
              open(HERE / 'calib_model.json', 'w'), indent=1)
    np.savez(HERE / 'calib_preds.npz', fold=fold, season=D['season'], **preds)
    print('saved calib_model.json and calib_preds.npz')


if __name__ == '__main__':
    main()
