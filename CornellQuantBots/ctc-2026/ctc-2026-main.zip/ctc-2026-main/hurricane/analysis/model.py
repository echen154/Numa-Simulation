"""Fundamental value model for the Hurricane Season case, fitted to 600 research seasons.
State: D[co] cumulative damage fraction (sum of damage_pct/100), C[co] weighted closure (sum weight*seconds/100),
L total insured loss $M, Lpgf insured loss from PORT/GRID/FERRY $M."""
import numpy as np
ISL=['PORT','ISLE','AQUA','GRID','FERRY']
LOSS_PER_PCT={'PORT':9.0,'ISLE':6.0,'AQUA':2.5,'GRID':7.0,'FERRY':1.2}
BASKET={'ARCH':{'PORT':1,'ISLE':1,'AQUA':2,'GRID':1,'FERRY':2,'HAVEN':1},'REBLD':{'RECON':2,'MAT':2,'GEN':1}}
# closure: site closed while I*exp(-(d/r)^2) > 0.35
CLOSE_TH=0.35
def value(D,C,L,Lpgf):
    v={}
    v['PORT']=100-55*D['PORT']-2*C['PORT']
    v['ISLE']=60-38*D['ISLE']
    v['AQUA']=35-20*D['AQUA']
    v['GRID']=50-24*D['GRID']-5*C['GRID']
    v['FERRY']=25-5*D['FERRY']-6*C['FERRY']
    v['RECON']=40+24*(1-np.exp(-Lpgf/1000))
    v['MAT']=28+14*(1-np.exp(-L/1200))
    v['GEN']=32+18*(1-np.exp(-0.83*C['GRID']))
    v['HAVEN']=75-0.06*np.clip(np.minimum(L,1300)-400,0,None)
    v['REIN']=90-0.035*np.clip(L-1300,0,None)
    for e,b in BASKET.items(): v[e]=sum(q*v[s] for s,q in b.items())
    return v
def loss_of(dpct):  # dpct: damage pct-points added by one storm
    L=sum(LOSS_PER_PCT[c]*dpct[c] for c in ISL)
    Lp=sum(LOSS_PER_PCT[c]*dpct[c] for c in ('PORT','GRID','FERRY'))
    return L,Lp
class StormBank:
    """Empirical future-storm draws: fractional damage (of remaining value) and closure per company."""
    def __init__(self,F,Cl): self.F=np.asarray(F); self.Cl=np.asarray(Cl)  # (n,5)
    def fair(self,D,C,L,Lp,n_future,nsim=4000,rng=None,weights=None):
        rng=rng or np.random.default_rng(0)
        if n_future==0: return value(D,C,L,Lp)
        Dm=np.tile([D[c] for c in ISL],(nsim,1)).astype(float); Cm=np.tile([C[c] for c in ISL],(nsim,1)).astype(float)
        Lm=np.full(nsim,float(L)); Lpm=np.full(nsim,float(Lp))
        lp=np.array([LOSS_PER_PCT[c] for c in ISL]); pg=np.array([1,0,0,1,1])
        for _ in range(n_future):
            idx=rng.integers(0,len(self.F),nsim)
            add=np.clip(1-Dm,0,None)*self.F[idx]          # fraction of original value
            Dm+=add; Cm+=self.Cl[idx]; Lm+=(add*100)@lp; Lpm+=(add*100*pg)@lp
        Dd={c:Dm[:,i] for i,c in enumerate(ISL)}; Cd={c:Cm[:,i] for i,c in enumerate(ISL)}
        v=value(Dd,Cd,Lm,Lpm)
        return {k:float(np.mean(x)) for k,x in v.items()}

class SiteBank:
    """Future storms drawn from research tracks, applied site by site to the remaining asset value."""
    def __init__(self,SF,CL,site_weights,noise_sd=0.25):
        self.SF=np.asarray(SF); self.CL=np.asarray(CL); self.sd=noise_sd
        self.w=[np.asarray(x) for x in site_weights]     # per company arrays
        self.slices=[]; i=0
        for x in self.w: self.slices.append(slice(i,i+len(x))); i+=len(x)
    def simulate(self,rem,D,C,L,Lp,n_future,nsim=4000,rng=None):
        rng=rng or np.random.default_rng(1)
        remm=np.tile(np.concatenate([rem[c] for c in ISL]),(nsim,1)).astype(float)
        Dm=np.tile([D[c] for c in ISL],(nsim,1)).astype(float); Cm=np.tile([C[c] for c in ISL],(nsim,1)).astype(float)
        Lm=np.full(nsim,float(L)); Lpm=np.full(nsim,float(Lp))
        lp=np.array([LOSS_PER_PCT[c] for c in ISL]); pg=np.array([1,0,0,1,1.0])
        for _ in range(n_future):
            idx=rng.integers(0,len(self.SF),nsim); noise=np.exp(rng.normal(-self.sd**2/2,self.sd,(nsim,5)))
            add=np.zeros((nsim,5))
            for i,c in enumerate(ISL):
                sl=self.slices[i]; ds=np.minimum(remm[:,sl]*self.SF[idx][:,sl]*noise[:,i:i+1],remm[:,sl])
                remm[:,sl]-=ds; add[:,i]=ds@self.w[i]
            Dm+=add; Cm+=self.CL[idx]; Lm+=(add*100)@lp; Lpm+=(add*100*pg)@lp
        return value({c:Dm[:,i] for i,c in enumerate(ISL)},{c:Cm[:,i] for i,c in enumerate(ISL)},Lm,Lpm)
    def fair(self,*a,**k):
        v=self.simulate(*a,**k); return {s:float(np.mean(x)) for s,x in v.items()}
