import pickle,json,numpy as np,pandas as pd
from forecast import ISL,SITES,LP,PG,exposure
T=pickle.load(open('tracks.pkl','rb')); df=pd.read_pickle('seasons.pkl').sort_index()
SYM=['PORT','ISLE','AQUA','GRID','FERRY','RECON','MAT','GEN','HAVEN','REIN','ARCH','REBLD']
def apply_report(rem,D,Cc,obs,dpct):
    """Update per-site remaining using the track model, scaled to the reported company damage."""
    L=0;Lp=0
    for i,co in enumerate(ISL):
        e,cl=exposure(obs,co); ds=rem[co]*(1-np.exp(-e)); pred=(SITES[co][:,2]*ds).sum()*100
        rep=dpct[co]
        if pred>1e-9: ds=ds*rep/pred
        elif rep>0: ds=rem[co]*rep/100/max(rem[co]@SITES[co][:,2],1e-9)
        rem[co]=np.clip(rem[co]-ds,0,1); D[co]+=rep/100; Cc[co]+=cl.sum()
        L+=LP[i]*rep; Lp+=LP[i]*PG[i]*rep
    return L,Lp
def site_state(s,upto):
    rem={co:np.ones(len(SITES[co])) for co in ISL}; D={co:0.0 for co in ISL}; Cc={co:0.0 for co in ISL}; L=0;Lp=0
    for r in range(1,upto):
        a,b=apply_report(rem,D,Cc,np.array(T[(s,r)]['obs']),{co:df.loc[s,f'd{r}_{co}'] for co in ISL}); L+=a;Lp+=b
    return rem,D,Cc,L,Lp
