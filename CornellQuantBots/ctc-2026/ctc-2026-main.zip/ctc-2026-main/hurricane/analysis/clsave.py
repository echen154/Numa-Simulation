import pickle,json,numpy as np,pandas as pd
T=pickle.load(open('tracks.pkl','rb'))
c=json.load(open('../data/hurricane-season-research/case.json'))
df=pd.read_pickle('seasons.pkl')
for co in ['PORT','ISLE','AQUA','GRID','FERRY']:
    for r in (1,2,3): df[f'cl{r}_{co}']=0.0
for (s,r),v in T.items():
    o=np.array(v['obs'])
    for co in ['PORT','ISLE','AQUA','GRID','FERRY']:
        tot=0
        for st in c['companies'][co]['sites']:
            q=np.hypot(o[:,1]-st['x'],o[:,2]-st['y'])/o[:,5]
            tot+=st['weight']*2*(o[:,6]*np.exp(-q*q)>0.35).sum()
        df.loc[s,f'cl{r}_{co}']=tot/100
for co in ['PORT','ISLE','AQUA','GRID','FERRY']: df['cl_'+co]=sum(df[f'cl{r}_{co}'] for r in (1,2,3))
df.to_pickle('seasons.pkl')
