import pickle,json,numpy as np
T=pickle.load(open('tracks.pkl','rb'))
c=json.load(open('../data/hurricane-season-research/case.json'))
sites={}
for co,v in c['companies'].items():
    for st in v['sites']: sites.setdefault(st['island'],[]).append((st['x'],st['y']))
ev=[]
for k,v in T.items():
    o=np.array(v['obs']); imp={m['island']:m['age'] for m in v['msgs'] if m['type']=='impact'}
    for isl,ss in sites.items():
        q=np.min([np.hypot(o[:,1]-x,o[:,2]-y) for x,y in ss],axis=0)/o[:,5]
        ev.append((o[:,0],q,o[:,6],imp.get(isl)))
def score(a,b,th):
    err=[];miss=0
    for age,q,I,ia in ev:
        w=I*np.exp(-(q/a)**b); idx=np.where(w>th)[0]
        pa=age[idx[0]] if len(idx) else None
        if (pa is None)!=(ia is None): miss+=1
        elif pa is not None: err.append(abs(pa-ia))
    return miss,np.mean(err) if err else 0,np.percentile(err,95) if err else 0
print('n impacts',sum(e[3] is not None for e in ev),'of',len(ev))
best=None
for a in [0.6,0.8,1.0,1.2]:
  for b in [1,1.5,2,3]:
    for th in [0.3,0.4,0.5,0.6,0.7]:
      s=score(a,b,th)
      if best is None or s[0]+s[1]<best[0][0]+best[0][1]: best=(s,a,b,th)
print(best)
