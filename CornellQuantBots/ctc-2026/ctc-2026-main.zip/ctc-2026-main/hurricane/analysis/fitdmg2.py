import pickle,json,numpy as np,pandas as pd
from scipy.optimize import least_squares
T=pickle.load(open('tracks.pkl','rb')); df=pd.read_pickle('seasons.pkl')
c=json.load(open('../data/hurricane-season-research/case.json'))
keys=sorted(T); O={k:np.array(T[k]['obs']) for k in keys}
site=c['companies']['PORT']['sites'][0]
W=[];dmg=[];prev=[]
for k in keys:
    s,r=k;o=O[k]; q=np.hypot(o[:,1]-site['x'],o[:,2]-site['y'])/o[:,5]; W.append(o[:,6]*np.exp(-q*q))
    dmg.append(df.loc[s,f'd{r}_PORT']/100); prev.append(sum(df.loc[s,f'd{j}_PORT'] for j in range(1,r))/100)
dmg=np.array(dmg);prev=np.array(prev)
def pred(p,usep):
    e=np.array([ (np.clip(w-p[0],0,None)**p[1]).sum()*p[2] for w in W])
    base=(1-prev) if usep else 1
    return base*(1-np.exp(-e))
for usep in (1,0):
    f=least_squares(lambda p:pred(p,usep)-dmg,[0.2,1.5,0.05],bounds=([0,0.2,1e-6],[0.99,8,50]))
    r=pred(f.x,usep)-dmg; print('prev-scaled' if usep else 'unscaled',f.x.round(4),'rmse %.4f'%np.sqrt((r**2).mean()))
    m=prev>0.3; print('   rmse on prev>0.3: %.4f n=%d'%(np.sqrt((r[m]**2).mean()),m.sum()))
