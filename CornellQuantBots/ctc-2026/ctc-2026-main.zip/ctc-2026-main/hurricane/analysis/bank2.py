import pickle,numpy as np,pandas as pd
from forecast import *
T=pickle.load(open('tracks.pkl','rb')); keys=sorted(T)
SF=[];CL=[]
for k in keys:
    o=np.array(T[k]['obs']); sf=[];cl=[]
    for co in ISL:
        e,c=exposure(o,co); sf.append(1-np.exp(-e)); cl.append(c.sum())
    SF.append(np.concatenate(sf)); CL.append(cl)
pickle.dump((np.array(SF),np.array(CL),keys),open('bank2.pkl','wb'))
# noise: ratio final/model for company-level
P=pd.read_pickle('prelim.pkl'); g=P[P.model>2]; print('log(final/model) sd by co',g.assign(l=np.log(g.final/g.model)).groupby('co').l.agg(['mean','std']).round(3))
