"""Train the storm-phase edge model (gradient boosting) used by the bot, and save it.

    cd analysis && ../.venv/bin/python calib_train.py

Writes bot/calib_gbm.pkl (all 600 seasons, for live trading) and bot/calib_gbm_fold{0..9}.pkl (each without one
tenth of the seasons, fold = season * 7919 % 10) so replay_test can test a season with a model that never saw it.
The model predicts (settlement - house mid) / mid from the features in calib_fit.features().
"""
import pickle, sys
from pathlib import Path
import numpy as np
from sklearn.ensemble import HistGradientBoostingRegressor
import calib_fit as C

BOT = Path(__file__).resolve().parent.parent / 'bot'


def model():
    return HistGradientBoostingRegressor(max_iter=300, learning_rate=0.05, max_leaf_nodes=31, min_samples_leaf=200,
                                         l2_regularization=1.0, categorical_features=[1, 2], random_state=0)


def main():
    D = C.load(); F = C.features(D); y = (D['settle'] - D['mid']) / D['mid']
    fold = (D['season'].astype(int) * 7919) % 10
    for k in list(range(10)) + [None]:
        tr = np.ones(len(y), bool) if k is None else fold != k
        g = model().fit(F[tr], y[tr])
        name = 'calib_gbm.pkl' if k is None else f'calib_gbm_fold{k}.pkl'
        pickle.dump(g, open(BOT / name, 'wb')); print('saved', name, flush=True)


if __name__ == '__main__':
    main()
