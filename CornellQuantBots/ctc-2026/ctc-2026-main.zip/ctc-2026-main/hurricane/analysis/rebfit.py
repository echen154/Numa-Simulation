import numpy as np,pandas as pd
from scipy.optimize import least_squares
df=pd.read_pickle('seasons.pkl')
D={co:df['add_'+co].values/100 for co in ['PORT','ISLE','AQUA','GRID','FERRY']}
C={co:df['cl_'+co].values for co in ['PORT','ISLE','AQUA','GRID','FERRY']}
def fit(name,y,cols,p0extra):
    n=len(cols)
    def f(p):
        X=sum(p[2+i]*cols[i] for i in range(n))
        return p[0]+p[1]*(1-np.exp(-X))
    p0=[y.min(),10]+[1]*n
    r=least_squares(lambda p:f(p)-y,p0,bounds=([0,0]+[0]*n,[500,500]+[100]*n))
    res=f(r.x)-y
    print(name,r.x.round(4),'resid sd %.4f max %.3f'%(res.std(),abs(res).max()))
    return r.x
y=df.set_RECON.values
fit('RECON pgf',y,[D['PORT'],D['GRID'],D['FERRY']],0)
fit('RECON all',y,[D[k] for k in D],0)
fit('MAT all',df.set_MAT.values,[D[k] for k in D],0)
fit('GEN gridcl',df.set_GEN.values,[C['GRID']],0)
fit('GEN gridcl+D',df.set_GEN.values,[C['GRID'],D['GRID']],0)
for s in ['RECON','MAT','GEN']: print(s,'min',df['set_'+s].min(),'max',df['set_'+s].max())
