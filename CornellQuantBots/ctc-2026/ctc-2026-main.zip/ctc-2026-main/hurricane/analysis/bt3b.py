import pickle,json,numpy as np,pandas as pd,sys
from pathlib import Path
from forecast import *
from model import value
exec(open('bt3.py').read().split("ages=")[0].split("keys=sorted(T)")[0])
keys=sorted(T)
m=json.load(open('../data/hurricane-season-research/history/manifest.json'))
truth={(s['season'],st['round']):(st['pattern'],st['turned_erratic_at']) for s in m['seasons'] for st in s['storms']}
F=PatternForecaster([np.array(T[k]['obs']) for k in keys],[truth[k] for k in keys]); kidx={k:i for i,k in enumerate(keys)}
exec(open('bt3.py').read().split("kidx={k:i for i,k in enumerate(keys)}")[1].split("ages=")[0])
ages=[30,60,90,120,150,180,240,300,360]
K=int(sys.argv[2]) if len(sys.argv)>2 else 40
rows=[]
for s in list(df.index)[::int(sys.argv[1])]:
    rem,D,Cc,L,Lp=site_state(s,3)
    o=np.array(T[(s,3)]['obs']); msgs=T[(s,3)]['msgs']
    mk=pd.read_csv(R/f'season-{s:03d}'/'market.csv'); g=mk[mk['round']==3].reset_index(drop=True)
    excl=[kidx[(s,r)] for r in (1,2,3)]
    for a in ages:
        part=o[o[:,0]<=a]
        off=[x['outlook'] for x in msgs if x['type']=='advisory' and x['source']=='official' and x['age']<=a]
        wir=[x['outlook'] for x in msgs if x['type']=='advisory' and x['source']=='wire' and x['age']<=a]
        post=pattern_posterior(off,wir)
        dist=F.complete(part,rem,k=K,exclude=excl,post=post)
        fv={k:0.0 for k in SYM}
        for wt,dp,cl in dist:
            D2={co:D[co]+dp[i]/100 for i,co in enumerate(ISL)}; C2={co:Cc[co]+cl[i] for i,co in enumerate(ISL)}
            v=value(D2,C2,L+(LP*dp).sum(),Lp+(LP*PG*dp).sum())
            for k in SYM: fv[k]+=wt*v[k]
        hp=g.iloc[min(30+a//2+2,len(g)-1)]
        for k in SYM: rows.append(dict(s=s,age=a,sym=k,fair=fv[k],house=hp[k],settle=df.loc[s,'set_'+k]))
X=pd.DataFrame(rows); X.to_pickle('bt3b.pkl')
X['ef']=(X.fair-X.settle).abs(); X['eh']=(X.house-X.settle).abs()
t=X.pivot_table(index='sym',columns='age',values='ef').round(2); h=X.pivot_table(index='sym',columns='age',values='eh').round(2)
print('OURS'); print(t.loc[['PORT','HAVEN','ISLE','GRID','RECON','ARCH']]); print('HOUSE'); print(h.loc[['PORT','HAVEN','ISLE','GRID','RECON','ARCH']])
