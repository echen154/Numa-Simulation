import pandas as pd,numpy as np,pickle
df=pd.read_pickle('seasons.pkl')
ISL=['PORT','ISLE','AQUA','GRID','FERRY']
F=[];Cl=[]
for _,row in df.iterrows():
    prev={c:0.0 for c in ISL}
    for r in (1,2,3):
        F.append([ (row[f'd{r}_{c}']/100)/max(1-prev[c],1e-6) for c in ISL]); Cl.append([row[f'cl{r}_{c}'] for c in ISL])
        for c in ISL: prev[c]+=row[f'd{r}_{c}']/100
pickle.dump((np.array(F),np.array(Cl)),open('bank.pkl','wb'))
print(np.array(F).mean(0).round(3),np.array(Cl).mean(0).round(3))
