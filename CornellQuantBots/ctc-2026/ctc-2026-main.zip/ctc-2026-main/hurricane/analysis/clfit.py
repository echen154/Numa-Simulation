import pickle,json,numpy as np,pandas as pd
from scipy.optimize import minimize
T=pickle.load(open('tracks.pkl','rb'))
c=json.load(open('../data/hurricane-season-research/case.json'))
df=pd.read_pickle('seasons.pkl')
keys=sorted(T); O={k:np.array(T[k]['obs']) for k in keys}
COS=['PORT','GRID','FERRY']
Qs={(k,co,i):np.hypot(O[k][:,1]-st['x'],O[k][:,2]-st['y'])/O[k][:,5] for k in keys for co in COS for i,st in enumerate(c['companies'][co]['sites'])}
seasons=df.index.values
def closures(qcrit_fn):
    out={co:np.zeros(len(seasons)) for co in COS}
    si={s:j for j,s in enumerate(seasons)}
    for k in keys:
        I=O[k][:,6]
        for co in COS:
            for i,st in enumerate(c['companies'][co]['sites']):
                out[co][si[k[0]]]+=st['weight']*2*qcrit_fn(Qs[(k,co,i)],I).sum()
    return out
def loss(p,ret=False):
    a,b,th=p
    cl=closures(lambda q,I: I*np.exp(-(q/a)**b)>th)
    tot=0;res={}
    for co in COS:
        X=np.c_[np.ones(len(df)),df['add_'+co]/100,cl[co]/100]; y=df['set_'+co].values
        bb,*_=np.linalg.lstsq(X,y,rcond=None); r=y-X@bb; tot+=(r**2).mean(); res[co]=(bb.round(3),r.std().round(4),abs(r).max().round(3))
    if ret: return res
    return tot
best=None
for a in [0.9,1.0,1.1]:
  for b in [2,2.5,3,4]:
    for th in [0.25,0.3,0.35,0.4,0.5]:
      l=loss((a,b,th))
      if best is None or l<best[0]: best=(l,a,b,th)
print(best)
print(loss(best[1:],True))
