import pickle,json,numpy as np,pandas as pd
from forecast import *
T=pickle.load(open('tracks.pkl','rb')); df=pd.read_pickle('seasons.pkl').sort_index()
exec(open('bt3.py').read().split("def site_state")[1].join(["def site_state",""]).split("ages=")[0]) if False else None
src=open('bt3.py').read(); exec("def site_state"+src.split("def site_state")[1].split("ages=")[0])
SYM=None
rows=[]
for s in df.index:
    for r in (1,2,3):
        rem,D,Cc,L,Lp=site_state(s,r)
        o=np.array(T[(s,r)]['obs']); pr=[m for m in T[(s,r)]['msgs'] if m['type']=='damage_report' and m['stage']=='preliminary'][0]
        for co in ISL:
            e,_=exposure(o,co); mdl=100*(SITES[co][:,2]*rem[co]*(1-np.exp(-e))).sum()
            rows.append(dict(s=s,r=r,co=co,model=mdl,prelim=pr['damage_pct'][co],final=df.loc[s,f'd{r}_{co}']))
X=pd.DataFrame(rows); X.to_pickle('prelim.pkl')
for co,g in X.groupby('co'):
    A=np.c_[g.model,g.prelim]; b,*_=np.linalg.lstsq(A,g.final,rcond=None)
    rm=lambda p: np.sqrt(((p-g.final)**2).mean())
    print(co,'w(model,prelim)=',b.round(3),'rmse model %.2f prelim %.2f prelim/1.05 %.2f combo %.2f'%(rm(g.model),rm(g.prelim),rm(g.prelim/1.05),rm(A@b)))
# is the noise multiplicative? ratio final/model sd and corr across companies
X['lr']=np.log((X.final+0.5)/(X.model+0.5)); X['lp']=np.log((X.prelim+0.5)/(X.final+0.5))
w=X[X.final>3].pivot_table(index=['s','r'],columns='co',values='lr'); print('corr of model residual across cos\n',w.corr().round(2))
w=X[X.final>3].pivot_table(index=['s','r'],columns='co',values='lp'); print('corr of prelim noise across cos\n',w.corr().round(2))
