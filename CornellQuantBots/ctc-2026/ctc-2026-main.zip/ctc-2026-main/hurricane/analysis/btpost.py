import pickle,json,numpy as np,pandas as pd
from pathlib import Path
from forecast import *; from model import value
R=Path('../data/hurricane-season-research/history')
T=pickle.load(open('tracks.pkl','rb')); df=pd.read_pickle('seasons.pkl').sort_index()
src=open('bt3.py').read(); exec("def site_state"+src.split("def site_state")[1].split("ages=")[0])
P=pd.read_pickle('prelim.pkl').set_index(['s','r','co'])
WM={'AQUA':.805,'FERRY':.718,'GRID':.735,'ISLE':.75,'PORT':.746}; WP={'AQUA':.186,'FERRY':.264,'GRID':.251,'ISLE':.232,'PORT':.245}
SYM=['PORT','ISLE','AQUA','GRID','FERRY','RECON','MAT','GEN','HAVEN','REIN','ARCH','REBLD']
rows=[]
for s in df.index[::2]:
    rem,D,Cc,L,Lp=site_state(s,3); o=np.array(T[(s,3)]['obs'])
    mk=pd.read_csv(R/f'season-{s:03d}'/'market.csv'); g=mk[mk['round']==3].reset_index(drop=True)
    cl={co:exposure(o,co)[1].sum() for co in ISL}
    for stage in ('model','combo'):
        dp=np.array([P.loc[(s,3,co),'model'] if stage=='model' else WM[co]*P.loc[(s,3,co),'model']+WP[co]*P.loc[(s,3,co),'prelim'] for co in ISL])
        v=value({co:D[co]+dp[i]/100 for i,co in enumerate(ISL)},{co:Cc[co]+cl[co] for co in ISL},L+(LP*dp).sum(),Lp+(LP*PG*dp).sum())
        for a in ([490,505] if stage=='model' else [520,560,640,720]):
            hp=g.iloc[min(30+a//2+1,len(g)-1)]
            for k in SYM: rows.append(dict(s=s,age=a,sym=k,fair=v[k],house=hp[k],settle=df.loc[s,'set_'+k]))
X=pd.DataFrame(rows); X['ef']=(X.fair-X.settle).abs(); X['eh']=(X.house-X.settle).abs(); X['sig']=X.fair-X.house; X['ret']=X.settle-X.house
print('OURS\n',X.pivot_table(index='sym',columns='age',values='ef').round(2)); print('HOUSE\n',X.pivot_table(index='sym',columns='age',values='eh').round(2))
print('beta\n',X.groupby(['sym','age']).apply(lambda g: np.polyfit(g.sig,g.ret,1)[0]).unstack().round(2))
X.to_pickle('btpost.pkl')
