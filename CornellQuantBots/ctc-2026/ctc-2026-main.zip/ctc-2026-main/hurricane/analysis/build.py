import json,csv,sys
from pathlib import Path
import pandas as pd
R=Path('../data/hurricane-season-research/history')
m=json.load(open(R/'manifest.json'))
SYM=["PORT","ISLE","AQUA","GRID","FERRY","RECON","MAT","GEN","HAVEN","REIN","ARCH","REBLD"]
rows=[];rr=[]
for s in m['seasons']:
    d=R/s['dir']; mk=pd.read_csv(d/'market.csv'); st=json.load(open(d/'settlement.json'))
    row={'season':s['season'],'loss':s['season_loss_musd']}
    for sym in SYM:
        row['open_'+sym]=mk[sym].iloc[0]; row['set_'+sym]=st[sym]
        for r in (1,2,3):
            g=mk[mk['round']==r][sym]; row[f'o{r}_'+sym]=g.iloc[0]; row[f'c{r}_'+sym]=g.iloc[-1]
    cum=0
    for stm in s['storms']:
        r=stm['round']; cum+=stm['industry_loss_musd']; row[f'L{r}']=stm['industry_loss_musd']; row[f'pat{r}']=stm['pattern']; row[f'err{r}']=stm['turned_erratic_at']
        for k,v in stm['damage_pct'].items(): row[f'd{r}_'+k]=v
    rows.append(row)
df=pd.DataFrame(rows); df.to_pickle('seasons.pkl'); print(df.shape)
print(df[[c for c in df.columns if c.startswith('open_')]].describe().T[['mean','std','min','max']])
