import json,pickle
from pathlib import Path
R=Path('../data/hurricane-season-research/history')
m=json.load(open(R/'manifest.json'))
out={}
types=set()
for s in m['seasons']:
    msgs=[json.loads(l) for l in open(R/s['dir']/'feed.jsonl')]
    for msg in msgs: types.add((msg['type'],msg.get('source'),msg.get('stage')))
    for r in (1,2,3):
        obs=[(x['age'],x['x'],x['y'],x['vx'],x['vy'],x['radius'],x['intensity']) for x in msgs if x['type']=='storm' and x['round']==r]
        out[(s['season'],r)]={'obs':obs,'msgs':[x for x in msgs if x['round']==r and x['type']!='storm' and x['type']!='track']}
pickle.dump(out,open('tracks.pkl','wb'))
print(sorted(types,key=str))
k=(1,1);print(len(out[k]['obs']),out[k]['obs'][:3],out[k]['obs'][-3:])
