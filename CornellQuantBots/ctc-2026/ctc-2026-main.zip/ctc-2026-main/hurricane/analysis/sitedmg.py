import pickle,json,numpy as np,pandas as pd
from scipy.optimize import least_squares
T=pickle.load(open('tracks.pkl','rb')); df=pd.read_pickle('seasons.pkl').sort_index()
c=json.load(open('../data/hurricane-season-research/case.json'))
ISL=['PORT','ISLE','AQUA','GRID','FERRY']
seasons=list(df.index)
W={}  # (co) -> list over seasons of list over rounds of array (nsite, nobs)
for co in ISL:
    W[co]=[]
    for s in seasons:
        rr=[]
        for r in (1,2,3):
            o=np.array(T[(s,r)]['obs'])
            rr.append(np.array([o[:,6]*np.exp(-(np.hypot(o[:,1]-st['x'],o[:,2]-st['y'])/o[:,5])**2) for st in c['companies'][co]['sites']]))
        W[co].append(rr)
params={}
for co in ISL:
    wts=np.array([st['weight'] for st in c['companies'][co]['sites']])
    y=np.array([[df.loc[s,f'd{r}_{co}']/100 for r in (1,2,3)] for s in seasons])
    def pred(p):
        th,pw,k=p; out=np.zeros_like(y)
        for i in range(len(seasons)):
            rem=np.ones(len(wts))
            for r in range(3):
                e=(np.clip(W[co][i][r]-th,0,None)**pw).sum(1)*k
                ds=rem*(1-np.exp(-e)); out[i,r]=(wts*ds).sum(); rem=rem-ds
        return out
    f=least_squares(lambda p:(pred(p)-y).ravel(),[0.05,1.0,0.02],bounds=([0,0.2,1e-6],[0.9,6,50]))
    res=pred(f.x)-y; params[co]=f.x.tolist()
    print(co,f.x.round(4),'rmse (pct-pts) %.2f'%(100*np.sqrt((res**2).mean())),'mean final %.2f'%(100*y.mean()))
json.dump(params,open('dmg_params.json','w'))
