import pickle,json,numpy as np,pandas as pd
T=pickle.load(open('tracks.pkl','rb'))
c=json.load(open('../data/hurricane-season-research/case.json'))
df=pd.read_pickle('seasons.pkl').set_index('season')
A,B,TH=1.0,3.0,0.3
def wind(o,x,y): q=np.hypot(o[:,1]-x,o[:,2]-y)/o[:,5]; return o[:,6]*np.exp(-(q/A)**B)
for co in ['PORT','ISLE','AQUA','GRID','FERRY']:
    for r in (1,2,3): df[f'cl{r}_{co}']=0.0
    for (s,r),v in T.items():
        o=np.array(v['obs'])
        tot=sum(st['weight']*2*(wind(o,st['x'],st['y'])>TH).sum() for st in c['companies'][co]['sites'])
        df.loc[s,f'cl{r}_{co}']=tot
    df['cl_'+co]=sum(df[f'cl{r}_{co}'] for r in (1,2,3))
df.to_pickle('seasons.pkl')
for co in ['PORT','ISLE','AQUA','GRID','FERRY']:
    X=np.c_[np.ones(len(df)),df['add_'+co]/100,df['cl_'+co]/100]; y=df['set_'+co]
    b,*_=np.linalg.lstsq(X,y,rcond=None); r=y-X@b
    print(co,b.round(4),'resid sd %.4f max %.3f'%(r.std(),abs(r).max()))
