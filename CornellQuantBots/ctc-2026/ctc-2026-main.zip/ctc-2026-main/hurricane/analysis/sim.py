import pandas as pd,numpy as np,glob,sys
SYM=['PORT','ISLE','AQUA','GRID','FERRY','RECON','MAT','GEN','HAVEN','REIN','ARCH','REBLD']
LIM={'PORT':200,'ISLE':300,'AQUA':500,'GRID':400,'FERRY':800,'RECON':500,'MAT':700,'GEN':600,'HAVEN':250,'REIN':200,'ARCH':50,'REBLD':100}
def load():
    return pd.concat([pd.read_pickle(f) for f in glob.glob('bteng_*.pkl') if '1_2' not in f])
def sim(X,beta,band=0.015,min_edge=0.003,half=0.002,syms=SYM,clip=0.25):
    res=[]
    for s,g in X.groupby('season'):
        pnl={k:0.0 for k in syms}; pos={k:0 for k in syms}; gross=0
        for _,row in g.iterrows():
            b=beta.get(row['phase'],0.5)
            for k in syms:
                h=row['h_'+k]; f=row['f_'+k]; adj=h+b*(f-h); e=adj-h; L=LIM[k]
                if abs(e)<(half+min_edge)*h: continue
                net=e-np.sign(e)*half*h; tgt=int(np.clip(net/(band*h),-1,1)*L)
                d=tgt-pos[k]
                d=int(np.sign(d)*min(abs(d),max(1,L*clip)))
                if d==0: continue
                px=h*(1+half*np.sign(d))
                if (d>0 and px>adj) or (d<0 and px<adj): continue
                pnl[k]+=d*(row['s_'+k]-px); pos[k]+=d; gross+=abs(d)*px
        res.append(dict(season=s,total=sum(pnl.values()),**pnl))
    return pd.DataFrame(res)
if __name__=='__main__':
    X=load(); print('seasons',X.season.nunique())
    base={'pre_storm':0.8,'storm':0.5,'aftermath':0.6,'prelim':0.6,'final':0.9}
    for name,beta in [('base',base),('all1',{k:1 for k in base}),('all0.5',{k:.5 for k in base}),('no-storm',{**base,'storm':0}),('only-storm',{k:(0.5 if k=='storm' else 0) for k in base}),('only-pre',{k:(0.8 if k in('pre_storm','final') else 0) for k in base})]:
        for half in (0.001,0.003):
            r=sim(X,beta,half=half); print(f'{name:10s} half={half}: mean {r.total.mean():8.0f}  sd {r.total.std():7.0f}  se {r.total.std()/np.sqrt(len(r)):5.0f}  win% {100*(r.total>0).mean():.0f}')
