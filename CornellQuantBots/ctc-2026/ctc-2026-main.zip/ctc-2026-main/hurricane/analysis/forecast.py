"""Live storm forecaster: damage-so-far from the observed track + analog completion from research storms."""
import json,numpy as np
C=json.load(open('../data/hurricane-season-research/case.json'))
ISL=['PORT','ISLE','AQUA','GRID','FERRY']
DP=json.load(open('dmg_params.json'))
SITES={co:np.array([[s['x'],s['y'],s['weight']] for s in C['companies'][co]['sites']]) for co in ISL}
LP=np.array([9.0,6.0,2.5,7.0,1.2]); PG=np.array([1,0,0,1,1.0])
def site_wind(obs,co):
    """obs: (n,7) age,x,y,vx,vy,r,I -> (nsite,n) wind"""
    S=SITES[co]; q=np.hypot(obs[None,:,1]-S[:,0,None],obs[None,:,2]-S[:,1,None])/obs[None,:,5]
    return obs[None,:,6]*np.exp(-q*q)
def exposure(obs,co):
    th,pw,k=DP[co]; w=site_wind(obs,co)
    return (np.clip(w-th,0,None)**pw).sum(1)*k, 2*(w>0.35).sum(1)*SITES[co][:,2]/100   # per-site exposure, closure units
class Forecaster:
    def __init__(self,bank_obs):
        """bank_obs: list of (n,7) arrays of full research storms (age 0..480 every 2 s)."""
        self.bank=[np.asarray(b) for b in bank_obs]
        self.ages=np.arange(0,482,2)
        P=np.full((len(self.bank),len(self.ages),6),np.nan)   # x,y,vx,vy,r,I by age index
        for j,b in enumerate(self.bank):
            idx=(b[:,0]//2).astype(int); P[j,idx]=b[:,1:7]
        self.P=P
    def analogs(self,obs,k=40,exclude=None):
        a=int(obs[-1,0])//2
        # compare track sampled every 10 s over the last 120 s plus current velocity
        hist=[i for i in range(max(0,a-60),a+1,5)]
        live=np.full((len(hist),2),np.nan); idx=(obs[:,0]//2).astype(int)
        m={int(i):n for n,i in enumerate(idx)}
        for h,i in enumerate(hist):
            if i in m: live[h]=obs[m[i],1:3]
        ok=~np.isnan(live[:,0])
        d=np.nansum(((self.P[:,hist,0:2][:,ok]-live[ok])**2).sum(2),1)/max(ok.sum(),1)
        vel=obs[-1,3:5]; d+=200*((self.P[:,a,2:4]-vel)**2).sum(1)
        if exclude is not None: d[list(exclude)]=np.inf
        d[np.isnan(d)]=np.inf
        nn=np.argsort(d)[:k]; w=np.exp(-d[nn]/max(np.median(d[nn]),1e-6)); return nn,w/w.sum(),a
    def complete(self,obs,rem_site,k=40,exclude=None):
        """Distribution of this storm's final damage pct and closure per company, given the observed track
        and per-site remaining fraction before this storm (rem_site[co] array). Returns list of (weight, dpct[5], cl[5])."""
        obs=np.asarray(obs); nn,w,a=self.analogs(obs,k,exclude,getattr(self,'_post',None)) if getattr(self,'_post',None) is not None else self.analogs(obs,k,exclude)
        out=[]
        cur=obs[-1,1:3]
        so_far={co:exposure(obs,co) for co in ISL}
        for j,wt in zip(nn,w):
            fut=self.bank[j][self.bank[j][:,0]>2*a].copy()
            if len(fut):
                off=cur-self.P[j,a,0:2]; fut[:,1:3]+=off*np.exp(-(fut[:,0]-2*a)/120.0)[:,None]  # shift fades out
            dp=[];cl=[]
            for i,co in enumerate(ISL):
                e0,c0=so_far[co]
                if len(fut): e1,c1=exposure(fut,co)
                else: e1,c1=0,0
                ds=rem_site[co]*(1-np.exp(-(e0+e1)))
                dp.append(100*(SITES[co][:,2]*ds).sum()); cl.append((c0+c1).sum())
            out.append((wt,np.array(dp),np.array(cl)))
        return out

PATS=['direct','chain','recurve','stall','eyewall','erratic']
def pattern_posterior(official,wire,p_off=0.70,p_wire=0.40,prior=None):
    """official/wire: lists of outlook keys seen so far for this storm."""
    lp=np.log(np.array(prior) if prior is not None else np.ones(6)/6)
    P=np.array(PATS)
    for o in official: lp+=np.log(np.where(P==o,p_off,(1-p_off)/5))
    for w in wire: lp+=np.log(np.where(P==w,p_wire,(1-p_wire)/5))
    p=np.exp(lp-lp.max()); return p/p.sum()
class PatternForecaster(Forecaster):
    def __init__(self,bank_obs,bank_truth):
        super().__init__(bank_obs); self.truth=bank_truth   # list of (pattern, turned_erratic_at)
    def pat_at(self,a_sec):
        return np.array([PATS.index('erratic' if (f is not None and a_sec>=f) else p) for p,f in self.truth])
    def analogs(self,obs,k=40,exclude=None,post=None):
        if post is None: return super().analogs(obs,k,exclude)
        a=int(obs[-1,0])//2
        hist=[i for i in range(max(0,a-60),a+1,5)]
        idx=(obs[:,0]//2).astype(int); m={int(i):n for n,i in enumerate(idx)}
        live=np.array([obs[m[i],1:3] if i in m else [np.nan,np.nan] for i in hist]); ok=~np.isnan(live[:,0])
        d=np.nansum(((self.P[:,hist,0:2][:,ok]-live[ok])**2).sum(2),1)/max(ok.sum(),1)
        d+=200*((self.P[:,a,2:4]-obs[-1,3:5])**2).sum(1)
        if exclude is not None: d[list(exclude)]=np.inf
        d[np.isnan(d)]=np.inf
        pa=self.pat_at(2*a); nn_all=[];w_all=[]
        for pi,pp in enumerate(post):
            if pp<0.01: continue
            cand=np.where((pa==pi)&np.isfinite(d))[0]
            if len(cand)==0: continue
            kk=max(3,int(round(k*pp))); nn=cand[np.argsort(d[cand])[:kk]]
            w=np.exp(-d[nn]/max(np.median(d[nn]),1e-6)); w=w/w.sum()*pp
            nn_all+=list(nn); w_all+=list(w)
        w=np.array(w_all); return np.array(nn_all),w/w.sum(),a
    def complete(self,obs,rem_site,k=40,exclude=None,post=None):
        self._post=post
        return super().complete(obs,rem_site,k,exclude)
