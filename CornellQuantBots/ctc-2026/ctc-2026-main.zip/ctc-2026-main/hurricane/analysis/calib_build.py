"""Build the calibration dataset: for every research season, replay the feed through the engine (with that season's
own storms hidden from the analogs, exactly as in replay_test.py) and record, every EVERY rows (2 s each):
the engine's fair value, the house price and context features. The settlement is the target.

    cd analysis && ../.venv/bin/python calib_build.py [--every 5] [--procs 6]

Writes calib_data/season-NNN.npz. calib_fit.py trains on them.
"""
import argparse, csv, json, multiprocessing as mp, sys
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'bot'))
from engine import Engine, SYMBOLS, PATS, pattern_posterior   # noqa: E402

HIST = HERE.parent / 'data/hurricane-season-research/history'
OUT = HERE / 'calib_data'
PHASES = ['pre_storm', 'storm', 'aftermath', 'prelim', 'final']


def build(args):
    season, every = args
    out = OUT / f'season-{season:03d}.npz'
    if out.exists():
        return season
    d = HIST / f'season-{season:03d}'
    feed = [json.loads(l) for l in open(d / 'feed.jsonl')]
    rows = list(csv.DictReader(open(d / 'market.csv')))
    settle = json.load(open(d / 'settlement.json'))
    e = Engine(nsim=1500); e.state_file = None; e.reset_season(); e.use = e.bseason != season
    mids = np.array([[float(r[s]) for s in SYMBOLS] for r in rows])
    rec = {k: [] for k in ('row', 'round', 'rrow', 'phase', 'conf', 'nadv', 'age', 'since_news', 'fair')}
    fi, last_news, rstart, cur_round = 0, 0, 0, 1
    for i, r in enumerate(rows):
        rnd = int(r['round'])
        if rnd != cur_round:
            cur_round, rstart = rnd, i
        while fi < len(feed) and feed[fi]['time'] <= r['time']:
            m = feed[fi]; e.on_message(m); fi += 1
            if m.get('type') in ('advisory', 'damage_report', 'impact', 'storm_formed', 'storm_dissipated'):
                last_news = i
        if i % every:
            continue
        fv, ph = e.fair()
        post = pattern_posterior(e.official, e.wire)
        rec['row'].append(i); rec['round'].append(rnd); rec['rrow'].append(i - rstart)
        rec['phase'].append(PHASES.index(ph)); rec['conf'].append(post.max()); rec['nadv'].append(len(e.official))
        rec['age'].append(max(e.obs) if e.obs else -1); rec['since_news'].append(i - last_news)
        rec['fair'].append([fv[s] for s in SYMBOLS])
    np.savez(out, mids=mids, settle=np.array([settle[s] for s in SYMBOLS]),
             **{k: np.array(v, float) for k, v in rec.items()})
    return season


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--every', type=int, default=5)
    ap.add_argument('--procs', type=int, default=6); ap.add_argument('--seasons', default='1-600')
    a = ap.parse_args()
    lo, hi = map(int, a.seasons.split('-'))
    OUT.mkdir(exist_ok=True)
    with mp.Pool(a.procs) as pool:
        for n, s in enumerate(pool.imap_unordered(build, [(s, a.every) for s in range(lo, hi + 1)]), 1):
            if n % 50 == 0:
                print(f'{n} seasons done', flush=True)


if __name__ == '__main__':
    main()
