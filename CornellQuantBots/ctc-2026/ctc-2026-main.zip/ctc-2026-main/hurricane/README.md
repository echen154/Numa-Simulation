# Hurricane Season Bot

A trading bot for the Cornell Trading Competition "Hurricane Season" case (systematic equities). It reads the storm news from the exchange, works out what each of the 12 symbols will settle at, and trades toward those values. Score is total PnL after round 3 settles.

Working notes (key facts, rules that matter for code, TODO) are in [`DEV_NOTES.md`](DEV_NOTES.md). The full findings (settlement formulas, storm physics, how accurate each news source is, where the house is wrong, backtest) are in [`bot/STRATEGY.md`](bot/STRATEGY.md).

## Why it works

- **Settlement is a known formula.** Every symbol settles on a formula of cumulative damage D, weighted closure C and season insured loss L. For example PORT = 100 − 55·D − 2·C, HAVEN is the $400M–$1,300M loss layer, and REIN pays above $1,300M. If we know where the storm goes, we know the prices.
- **The storm is predictable.** Wind at a site is `intensity × exp(−(dist/radius)²)` and a site is closed while that is above 0.35. We replay 1,800 research storms (`bot/storm_bank.npz`) to simulate the rest of the season.
- **The news sources have known accuracy.** The official outlook is right 70% of the time and wire chatter 40%. The bot combines them with Bayes.
- **The house is slow and pessimistic.** It underprices the island companies and HAVEN at the open, overprices the rebuilders and REIN, and lags during the storm. Most backtest profit comes from trading during the storm.

Backtest over 600 research seasons: about $20k per season, and it won 94–96% of seasons.

## Layout

| Path | What it is |
|---|---|
| `bot/engine.py` | Fair-value engine. Feed it news (`on_message`), call `fair()` → 12 fair values + phase. |
| `bot/bot.py` | Live bot: WebSocket feed, valuation thread, trading thread, rate limiting, `control.json` overrides. |
| `bot/adjust.py` | Manual controls while the bot runs (pause, size, per-symbol overrides). |
| `bot/check_connection.py` | Read-only exchange check. Prints raw API/WebSocket messages. Places no orders. |
| `bot/replay_test.py` | Replays one research season against a fake exchange (with the 60/min rate limit). |
| `bot/sweep.py` | Runs replay_test over many seasons in parallel to compare parameter variants. |
| `bot/keys.txt` | Our bot API keys, one per line. |
| `analysis/` | The research scripts that produced STRATEGY.md. |
| `data/hurricane-season-research/` | Official research data README and starter kit. The `history/` folder is not in git (see Setup). |

## Setup (once)

1. Make a Python environment from inside `hurricane/`:
   ```bash
   python3 -m venv .venv && .venv/bin/pip install "websockets>=14" numpy pandas scipy
   ```
2. For replays only: unzip the official research data so that `data/hurricane-season-research/history/` exists. It is 214 MB, so it is not in git.
3. Check the connection (read-only, places no orders):
   ```bash
   cd bot && ../.venv/bin/python check_connection.py --url https://cornelltradingcompetition.org
   ```

## Running the bot

```bash
cd bot
../.venv/bin/python bot.py --url https://cornelltradingcompetition.org --dry-run       # watch, no orders
../.venv/bin/python bot.py --url https://cornelltradingcompetition.org --new-season    # live, first start of the season
../.venv/bin/python bot.py --url https://cornelltradingcompetition.org                 # live, restart mid-season
```

- Keys come from `bot/keys.txt` (or `--key K1,K2,K3`). With 3 keys each one trades its own group: island companies / rebuilders + insurers / ETFs. ETF create/redeem arbitrage is only on with 3 keys.
- `--size 0.5` trades at half the position limits.
- `--new-season` forgets the saved state. Use it only at the very start of the live season.
- The limits: 60 order actions per minute per key, 180 per team. Resting orders count toward position limits.

## During the competition

The bot re-reads `bot/control.json` about every 2 seconds. Change it with `adjust.py`:

```bash
python adjust.py pause | resume   # stop all trading and cancel orders / start again
python adjust.py size 0.5         # trade at half size
python adjust.py PORT -5          # PORT fair value $5 lower
python adjust.py flat HAVEN       # close HAVEN and leave it alone (unflat HAVEN to undo)
python adjust.py show             # print the current controls
```

**Announcements are not modelled.** If a company or government announcement comes out, a human has to adjust the bot. The house takes about 45 seconds to reprice, so be fast.

## Testing offline

```bash
cd bot
../.venv/bin/python replay_test.py --history ../data/hurricane-season-research/history --season 17
../.venv/bin/python replay_test.py --history ../data/hurricane-season-research/history --season 17 --no-arb
../.venv/bin/python sweep.py --history ../data/hurricane-season-research/history --seasons 40
```
