# Dev notes – CTC 2026 Systematic Equities (Hurricane Season)

Trading bot for the Cornell Trading Competition "Hurricane Season" case. Score = total PnL after round 3 settles.
The competition allows generative AI, but the team must understand the code and make the design and strategy decisions themselves.
So when you change code here, explain what you changed and why.

## Layout
- `bot/engine.py` – fair-value engine. Feed it news messages (`on_message`), call `fair()` → (dict of 12 fair values, phase).
- `bot/bot.py` – live bot: WebSocket feed, valuation thread, trading thread, rate limiting, `control.json` overrides.
- `bot/replay_test.py` – offline end-to-end test that replays one research season against a fake exchange (enforces the 60/min per-key rate limit; `--keys 1|2|3`).
- `bot/sweep.py` – runs replay_test over many seasons in parallel to compare parameter variants (paired differences).
- `bot/check_connection.py` – read-only testnet check: prints raw API/WebSocket shapes and whether bot.py parses them. Places no orders.
- `bot/storm_bank.npz` – 1,800 research storm tracks + per-site damage/closure (analogs and future storms).
- `bot/STRATEGY.md` – the findings: settlement formulas, storm physics, source accuracy, house biases, backtest.
- `analysis/` – the scripts that produced those findings (run from inside `analysis/`; some need pickles made by earlier scripts: build.py → tracks.py → clsave.py → sitedmg.py → bank2.py → prelim.py).
- `data/hurricane-season-research/` – the official research data and starter kit (README.md there explains every file).

## Key facts (from STRATEGY.md)
- Settlement is a known formula of cumulative damage D, weighted closure C and season insured loss L,
  e.g. PORT = 100 − 55·D − 2·C; HAVEN layer $400M–$1,300M; REIN above $1,300M.
- A site is closed while intensity·exp(−(dist/radius)²) > 0.35.
- Official outlook is right 70% of the time and wire chatter 40%. Combine them with Bayes.
- Most backtest profit comes from trading during the storm.

## Rules that matter for code
- 60 order actions/min per bot key, 180 per team; place, cancel, cancel-all, create and redeem each count.
- Position limits include resting orders on the same side.
- ETF create/redeem: POST /api/v1/etf/{ARCH|REBLD}/create|redeem {"quantity": n}. These are free and instant.

## Status / TODO
- [ ] Bot has NOT been run against the real exchange. Verify quote and positions message formats on the testnet with `--dry-run`
      (`Bot.on_frame`, `Bot.positions`).
- [x] Split trading across up to 3 bot keys: `--key K1,K2,K3`. Each key trades its own group (`KEY_GROUPS` in bot.py).
- [x] ETF create/redeem arbitrage (`Bot.etf_arb`). It is on by default only with 3 keys, because each arb costs 6–8 order actions.
      In replays it added very little (~$20/season), because the directional trading already trades ETF mispricings.
- [ ] Check on the testnet that quotes carry `bid_size`/`ask_size` (the arb uses them to cap size if present).
- [ ] Announcements are not modelled. A human sets overrides in `bot/control.json`.

## Commands
```bash
python3 -m venv .venv && .venv/bin/pip install "websockets>=14" numpy pandas scipy   # once; then use ../.venv/bin/python from bot/
cd bot && python check_connection.py --url https://cornelltradingcompetition.org --key KEY1
pip install "websockets>=14" numpy pandas scipy
cd bot && python replay_test.py --history ../data/hurricane-season-research/history --season 17
cd bot && python bot.py --url https://cornelltradingcompetition.org --key KEY1,KEY2,KEY3 --dry-run
cd bot && python replay_test.py --history ../data/hurricane-season-research/history --season 17 --no-arb   # compare without arb
```
