# CTC Options Desk

A one-page calculator for the Cornell Trading Competition derivatives case. You type in the news, it tells you which options to buy or sell, how many, and at what price. It does not connect to the exchange; one person runs the desk and reads out trades, another person clicks them in on the exchange.

## Why it works

After each news event the exchange bots are slow on purpose:

| Time after news | Bots quote options using | What that means |
|---|---|---|
| 0:00–1:00 | old price, old IV | a 60-strike call on oil that just went 100→110 is worth ~$10 more, and the bots are still selling it at the old price |
| 1:00–2:00 | new price, old IV | only the volatility change is still mispriced (smaller) |
| 2:00+ | correct | nothing left; this is when you sell back what you bought |

The desk runs Black-Scholes on all 12 contracts with the new numbers, compares to what the bots are still quoting, and ranks the gaps. You trade the top of the list, then close everything after 2:00. The money is the difference.

## Setup (5 minutes, once)

1. Download `options_desk.html` and double-click it. It opens in your browser. No internet needed. Everything you type is saved in the browser and survives a reload.
2. Add `#demo` to the end of the URL to see a sample event already filled in. Remove it when you're done playing (demo mode doesn't save).
3. Before Event 1 on the day, copy from the exchange into the desk:
   - each underlying's **strikes**, **spot now**, **IV now** (top of the OIL and PLANE panels)
   - **Days left** in the header, matching the exchange calculator's T (20 on day 1)
   - in the **Execution** card: the bots' spread, size per price level, and how many levels they post (read these off the order book)

## The loop for every event

**News appears**
1. Press `Esc` on the desk. A 2:30 clock starts and the cursor lands in OIL "new spot".
2. Type the announced numbers: new OIL price `Enter` new OIL IV `Enter` new PLANE price `Enter` new PLANE IV. (Rounds 2–3: the three analyst numbers instead of an IV.)

**0:10 to 1:00 — trade the ⏱ rows**
3. The "Top trades now" table fills in. Each row says side, contract, quantity, and a limit price. Click the price to copy it.
4. On the exchange: pick the contract, Buy or Sell, Limit, type the quantity and the limit price, send. Don't wait for fills; go to the next row.
5. Rows marked ⏱ disappear at 1:00 when the bots fix their price. Do those first, top down.

**1:00 — cancel leftovers**
6. Cancel anything still sitting in Open orders. Any row still on the desk is a vol trade; take it if you don't already hold it.

**2:00 — close and reset**
7. The bots are now at fair value. For each line in your Positions panel, send the opposite order (positive → sell that many, negative → buy that many). Market orders are fine. Positions panel empty.
8. On the desk, in "After the 2:00 snap": pick the 100 strike, Call, type the mid you see on the exchange, press **→ true IV**. In Round 1 this should match the announced IV (a sanity check). In Rounds 2–3 it's how the analysts get scored.
9. Type a 3-word note about the news, press `Alt+R` (or **Roll forward**). The new numbers become "now" and you're ready for the next event.

The next news comes 30 seconds after the 2:00 snap, so steps 7–9 are fast.

## Things that confuse everyone the first time

- **The limit price is not what you pay.** It's a cap. You fill at the bots' stale price, which is far better. The cap only stops you from overpaying if the bots reprice while your order is in flight.
- **"Edge" is what you keep per contract** after you close the trade. Quantity × edge, roughly, is the money. The Total column does that with the per-level price steps included.
- **SELL rows exist.** If oil goes up, puts are worth less, and the bots are still bidding the old high price for them. Selling something for more than it's worth is the same edge as buying for less. You don't need to own it first; you buy it back after 2:00.
- **No trades showing?** Look at the pill at the top: if it says "C · fair" the clock ran out and the desk assumes the bots have caught up. Press `Esc` to restart it, or click A to see the stale-quote edge.
- **The 600 quantity** is bot size per level × levels deep from the Execution card (defaults 200 × 3 from the packet screenshot). Set those from the live book. Sending more than is there is fine: the extra rests as an open order, which you cancel at 1:00.
- **The desk doesn't know your fills.** Rows you already traded show up again at 1:00 if the bots are still stale. Skip those.
- **Flatten after every event.** A 60-strike call on oil is basically a barrel of oil until you sell it. If you can't get out before the next news, type the position into the **Pos** column; the desk then shows what the next headline does to it and flags the unwind in the trades table.

## Rounds 2 and 3

Spot prices are still announced, so the big ⏱ trades are as certain as in Round 1. Only IV becomes a guess.

- **Round 2:** type the three analyst numbers instead of an IV. The desk combines them (median by default) and widens fair value by how much they disagree, so shaky vol trades drop off on their own. After each 2:00 snap do the **→ true IV** step; that scores the analysts. After two events switch "Combine" to "Weighted by track record".
- **Round 3:** the analysts give some quantity related to IV. In the "Vol from analysts" card, pick what it is from the "Analyst numbers are" dropdown if the game tells you. If not, trade only the ⏱ rows for the first event, record the true IV after the snap, and the "Which formula fits?" box ranks the candidates.
- The line under the trades table suggests a **synthetic** (buy call + sell put at one strike) when IV is uncertain. It captures the price move with the IV cancelling out.

## Roles

- **Caller**: runs the desk, types the numbers, reads rows aloud, does true IV and roll forward.
- **Clicker**: on the exchange, sends orders in the order called, closes positions at 2:00.
- **Clock**: watches the timer, cancels open orders at 1:00 and 2:00, checks Positions is empty before the next news.

## Shortcuts

| Key | Does |
|---|---|
| `Esc` | news just dropped: start the clock |
| `Enter` | next input box |
| `Alt+R` | roll forward to the next event |
| `Alt+1` / `2` / `3` | force phase A / B / C; `Alt+0` back to auto |
| click a price | copy it |

## Two questions to settle with the organizers before the day

1. Do matched orders fill at the resting order's price or at the midpoint? If midpoint, set **Exit cost** and **Bot spread** to 0 in the Execution card.
2. Is there a pause between events, or does the next news land straight after 2:30?
